'use client'

import Link from 'next/link'
import Image from 'next/image'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { MapPin, Eye, Heart, Star, ShieldCheck, Syringe, FileText } from 'lucide-react'
import type { Pet } from '@/lib/types'
import { cn } from '@/lib/utils'

interface PetCardProps {
  pet: Pet
  variant?: 'default' | 'compact'
}

export function PetCard({ pet, variant = 'default' }: PetCardProps) {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('ru-RU', {
      style: 'currency',
      currency: 'RUB',
      minimumFractionDigits: 0,
    }).format(price * 100)
  }

  const petEmoji = pet.type === 'DOG' 
    ? (pet.gender === 'MALE' ? '/placeholder.svg' : '/placeholder.svg')
    : '/placeholder.svg'

  return (
    <Link href={`/catalog/${pet.id}`}>
      <Card className={cn(
        "group overflow-hidden transition-all duration-300 hover:shadow-lg hover:-translate-y-1",
        "border-border/50 bg-card"
      )}>
        {/* Image */}
        <div className="relative aspect-[4/3] overflow-hidden bg-secondary">
          <Image
            src={pet.media?.[0]?.url || petEmoji}
            alt={pet.title}
            fill
            className="object-cover transition-transform duration-300 group-hover:scale-105"
          />
          
          {/* Badges */}
          <div className="absolute left-2 top-2 flex flex-col gap-1">
            {pet.isVip && (
              <Badge className="bg-warning text-warning-foreground">
                <Star className="mr-1 h-3 w-3" /> VIP
              </Badge>
            )}
            {pet.petClass === 'SHOW' && (
              <Badge variant="secondary" className="bg-primary/90 text-primary-foreground">
                Шоу-класс
              </Badge>
            )}
          </div>

          {/* Favorite button */}
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-2 top-2 h-8 w-8 rounded-full bg-background/80 backdrop-blur-sm hover:bg-background"
            onClick={(e) => {
              e.preventDefault()
              // Handle favorite
            }}
          >
            <Heart className="h-4 w-4" />
          </Button>

          {/* Views counter */}
          <div className="absolute bottom-2 right-2 flex items-center gap-1 rounded-full bg-background/80 px-2 py-1 text-xs backdrop-blur-sm">
            <Eye className="h-3 w-3" />
            {pet.views}
          </div>
        </div>

        {/* Content */}
        <CardContent className="p-4">
          <div className="mb-2 flex items-start justify-between gap-2">
            <h3 className="line-clamp-1 font-semibold text-foreground group-hover:text-primary">
              {pet.title}
            </h3>
          </div>

          <p className="mb-2 text-sm text-muted-foreground">
            {pet.breed} &bull; {pet.age} {pet.age === 1 ? 'месяц' : pet.age < 5 ? 'месяца' : 'месяцев'} &bull; {pet.gender === 'MALE' ? 'Мальчик' : 'Девочка'}
          </p>

          <div className="mb-3 text-xl font-bold text-primary">
            {formatPrice(pet.price)}
          </div>

          <div className="mb-3 flex items-center gap-1 text-sm text-muted-foreground">
            <MapPin className="h-3.5 w-3.5" />
            {pet.city}
          </div>

          {/* Trust indicators */}
          {variant === 'default' && (
            <div className="flex flex-wrap gap-2">
              {pet.hasPedigree && (
                <Badge variant="outline" className="text-xs">
                  <FileText className="mr-1 h-3 w-3" />
                  Родословная
                </Badge>
              )}
              {pet.hasVaccination && (
                <Badge variant="outline" className="text-xs text-accent">
                  <Syringe className="mr-1 h-3 w-3" />
                  Привит
                </Badge>
              )}
              {pet.hasHealthTests && (
                <Badge variant="outline" className="text-xs text-accent">
                  <ShieldCheck className="mr-1 h-3 w-3" />
                  Тесты здоровья
                </Badge>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </Link>
  )
}
