'use client'

import { useRouter, useSearchParams } from 'next/navigation'
import { useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { Dog, Cat, Filter, X } from 'lucide-react'
import { breeds } from '@/lib/data'

const cities = ['Москва', 'Санкт-Петербург', 'Казань', 'Новосибирск', 'Екатеринбург']
const petClasses = [
  { value: 'PET', label: 'Пет-класс' },
  { value: 'BREED', label: 'Брид-класс' },
  { value: 'SHOW', label: 'Шоу-класс' },
]

interface CatalogFiltersProps {
  onClose?: () => void
}

export function CatalogFilters({ onClose }: CatalogFiltersProps) {
  const router = useRouter()
  const searchParams = useSearchParams()

  const createQueryString = useCallback(
    (updates: Record<string, string | null>) => {
      const params = new URLSearchParams(searchParams.toString())
      Object.entries(updates).forEach(([key, value]) => {
        if (value === null || value === '' || value === 'all') {
          params.delete(key)
        } else {
          params.set(key, value)
        }
      })
      params.delete('page') // Reset page when filters change
      return params.toString()
    },
    [searchParams]
  )

  const updateFilter = (key: string, value: string | null) => {
    router.push(`/catalog?${createQueryString({ [key]: value })}`)
  }

  const clearFilters = () => {
    router.push('/catalog')
  }

  const hasFilters = searchParams.toString().length > 0

  // Получаем текущие значения фильтров, используя 'all' вместо ''
  const currentBreed = searchParams.get('breed') || 'all'
  const currentCity = searchParams.get('city') || 'all'
  const currentPetClass = searchParams.get('petClass') || 'all'

  return (
    <Card className="border-border/50">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Filter className="h-5 w-5" />
            Фильтры
          </CardTitle>
          {hasFilters && (
            <Button variant="ghost" size="sm" onClick={clearFilters} className="text-muted-foreground">
              <X className="mr-1 h-4 w-4" />
              Сбросить
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Pet Type */}
        <div className="space-y-3">
          <Label className="text-sm font-medium">Тип питомца</Label>
          <div className="flex gap-2">
            <Button
              variant={searchParams.get('type') === 'DOG' ? 'default' : 'outline'}
              size="sm"
              className="flex-1"
              onClick={() => updateFilter('type', searchParams.get('type') === 'DOG' ? null : 'DOG')}
            >
              <Dog className="mr-2 h-4 w-4" />
              Собаки
            </Button>
            <Button
              variant={searchParams.get('type') === 'CAT' ? 'default' : 'outline'}
              size="sm"
              className="flex-1"
              onClick={() => updateFilter('type', searchParams.get('type') === 'CAT' ? null : 'CAT')}
            >
              <Cat className="mr-2 h-4 w-4" />
              Кошки
            </Button>
          </div>
        </div>

        <Separator />

        {/* Breed - ИСПРАВЛЕНО */}
        <div className="space-y-3">
          <Label className="text-sm font-medium">Порода</Label>
          <Select
            value={currentBreed}
            onValueChange={(value) => updateFilter('breed', value === 'all' ? null : value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Все породы" />
            </SelectTrigger>
            <SelectContent>
              {/* ✅ ИСПРАВЛЕНО: используем 'all' вместо пустой строки */}
              <SelectItem value="all">Все породы</SelectItem>
              {breeds.map((breed) => (
                <SelectItem key={breed.slug} value={breed.slug}>
                  {breed.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* City - ИСПРАВЛЕНО */}
        <div className="space-y-3">
          <Label className="text-sm font-medium">Город</Label>
          <Select
            value={currentCity}
            onValueChange={(value) => updateFilter('city', value === 'all' ? null : value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Все города" />
            </SelectTrigger>
            <SelectContent>
              {/* ✅ ИСПРАВЛЕНО: используем 'all' вместо пустой строки */}
              <SelectItem value="all">Все города</SelectItem>
              {cities.map((city) => (
                <SelectItem key={city} value={city}>
                  {city}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Separator />

        {/* Price Range */}
        <div className="space-y-3">
          <Label className="text-sm font-medium">Диапазон цен</Label>
          <div className="flex gap-2">
            <Input
              type="number"
              placeholder="От"
              value={searchParams.get('priceMin') || ''}
              onChange={(e) => updateFilter('priceMin', e.target.value || null)}
              className="flex-1"
            />
            <span className="flex items-center text-muted-foreground">-</span>
            <Input
              type="number"
              placeholder="До"
              value={searchParams.get('priceMax') || ''}
              onChange={(e) => updateFilter('priceMax', e.target.value || null)}
              className="flex-1"
            />
          </div>
        </div>

        <Separator />

        {/* Pet Class - ИСПРАВЛЕНО */}
        <div className="space-y-3">
          <Label className="text-sm font-medium">Класс питомца</Label>
          <Select
            value={currentPetClass}
            onValueChange={(value) => updateFilter('petClass', value === 'all' ? null : value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Любой класс" />
            </SelectTrigger>
            <SelectContent>
              {/* ✅ ИСПРАВЛЕНО: используем 'all' вместо пустой строки */}
              <SelectItem value="all">Любой класс</SelectItem>
              {petClasses.map((pc) => (
                <SelectItem key={pc.value} value={pc.value}>
                  {pc.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Gender */}
        <div className="space-y-3">
          <Label className="text-sm font-medium">Пол</Label>
          <div className="flex gap-2">
            <Button
              variant={searchParams.get('gender') === 'MALE' ? 'default' : 'outline'}
              size="sm"
              className="flex-1"
              onClick={() => updateFilter('gender', searchParams.get('gender') === 'MALE' ? null : 'MALE')}
            >
              Мальчик
            </Button>
            <Button
              variant={searchParams.get('gender') === 'FEMALE' ? 'default' : 'outline'}
              size="sm"
              className="flex-1"
              onClick={() => updateFilter('gender', searchParams.get('gender') === 'FEMALE' ? null : 'FEMALE')}
            >
              Девочка
            </Button>
          </div>
        </div>

        <Separator />

        {/* Document Filters */}
        <div className="space-y-3">
          <Label className="text-sm font-medium">Документы и здоровье</Label>
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="pedigree"
                checked={searchParams.get('hasPedigree') === 'true'}
                onCheckedChange={(checked) => updateFilter('hasPedigree', checked ? 'true' : null)}
              />
              <label htmlFor="pedigree" className="text-sm cursor-pointer">
                Есть родословная
              </label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="vaccination"
                checked={searchParams.get('hasVaccination') === 'true'}
                onCheckedChange={(checked) => updateFilter('hasVaccination', checked ? 'true' : null)}
              />
              <label htmlFor="vaccination" className="text-sm cursor-pointer">
                Привит
              </label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="healthTests"
                checked={searchParams.get('hasHealthTests') === 'true'}
                onCheckedChange={(checked) => updateFilter('hasHealthTests', checked ? 'true' : null)}
              />
              <label htmlFor="healthTests" className="text-sm cursor-pointer">
                Тесты здоровья
              </label>
            </div>
          </div>
        </div>

        {/* Mobile Close Button */}
        {onClose && (
          <>
            <Separator />
            <Button className="w-full" onClick={onClose}>
              Применить фильтры
            </Button>
          </>
        )}
      </CardContent>
    </Card>
  )
}