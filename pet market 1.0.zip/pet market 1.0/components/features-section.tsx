import { ShieldCheck, Star, Gift, BadgeCheck } from 'lucide-react'

const features = [
  {
    icon: ShieldCheck,
    title: 'Проверенные заводчики',
    description: 'Все заводчики проходят тщательную проверку для гарантии надежности и качества.',
  },
  {
    icon: Star,
    title: 'Рейтинги заводчиков',
    description: 'Читайте отзывы реальных покупателей и принимайте обоснованные решения.',
  },
  {
    icon: BadgeCheck,
    title: 'Гарантии здоровья',
    description: 'Питомцы поставляются с медицинской документацией, прививками и родословными.',
  },
  {
    icon: Gift,
    title: 'Реферальные бонусы',
    description: 'Приглашайте друзей и получайте бонусы: бесплатные поднятия и VIP-статус.',
  },
]

export function FeaturesSection() {
  return (
    <section className="bg-card py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="mb-12 text-center">
          <h2 className="mb-4 text-3xl font-bold text-foreground md:text-4xl">
            Почему выбирают PetMarket
          </h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Мы делаем акцент на доверии и прозрачности, чтобы помочь вам безопасно найти идеального питомца.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="group rounded-xl border border-border/50 bg-background p-6 text-center transition-all hover:border-primary/20 hover:shadow-lg"
            >
              <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                <feature.icon className="h-7 w-7" />
              </div>
              <h3 className="mb-2 font-semibold text-foreground">{feature.title}</h3>
              <p className="text-sm text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
