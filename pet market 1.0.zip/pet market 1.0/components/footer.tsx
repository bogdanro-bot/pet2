import Link from 'next/link'
import { PawPrint } from 'lucide-react'

export function Footer() {
  return (
    <footer className="border-t border-border bg-secondary/30">
      <div className="container mx-auto px-4 py-12">
        <div className="grid gap-8 md:grid-cols-4">
          {/* Brand */}
          <div className="space-y-4">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                <PawPrint className="h-5 w-5" />
              </div>
              <span className="text-xl font-bold text-foreground">PetMarket</span>
            </Link>
            <p className="text-sm text-muted-foreground">
              Надежная площадка для поиска идеального питомца от проверенных заводчиков.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="mb-4 font-semibold text-foreground">Быстрые ссылки</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="/catalog" className="hover:text-foreground">Смотреть питомцев</Link></li>
              <li><Link href="/breeders" className="hover:text-foreground">Найти заводчика</Link></li>
              <li><Link href="/catalog?type=DOG" className="hover:text-foreground">Собаки</Link></li>
              <li><Link href="/catalog?type=CAT" className="hover:text-foreground">Кошки</Link></li>
            </ul>
          </div>

          {/* For Breeders */}
          <div>
            <h3 className="mb-4 font-semibold text-foreground">Для заводчиков</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="/dashboard" className="hover:text-foreground">Личный кабинет</Link></li>
              <li><Link href="/dashboard" className="hover:text-foreground">Разместить объявление</Link></li>
              <li><Link href="/dashboard" className="hover:text-foreground">VIP-пакеты</Link></li>
              <li><Link href="/dashboard" className="hover:text-foreground">Реферальная программа</Link></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="mb-4 font-semibold text-foreground">Поддержка</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="#" className="hover:text-foreground">Центр помощи</Link></li>
              <li><Link href="#" className="hover:text-foreground">Советы по безопасности</Link></li>
              <li><Link href="#" className="hover:text-foreground">Условия использования</Link></li>
              <li><Link href="#" className="hover:text-foreground">Политика конфиденциальности</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-12 border-t border-border pt-8 text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} PetMarket. Все права защищены.</p>
        </div>
      </div>
    </footer>
  )
}
