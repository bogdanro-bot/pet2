'use client'

import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import type { Breed } from '@/lib/types'
import { Dog, Cat } from 'lucide-react'

interface BreedCardProps {
  breed: Breed
}

export function BreedCard({ breed }: BreedCardProps) {
  return (
    <Link href={`/catalog?breed=${breed.slug}`}>
      <Card className="group overflow-hidden transition-all duration-300 hover:shadow-md hover:-translate-y-1 border-border/50">
        <CardContent className="flex flex-col items-center p-6 text-center">
          <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
            {breed.type === 'DOG' ? (
              <Dog className="h-8 w-8" />
            ) : (
              <Cat className="h-8 w-8" />
            )}
          </div>
          <h3 className="mb-1 font-semibold text-foreground group-hover:text-primary">
            {breed.name}
          </h3>
          <p className="text-sm text-muted-foreground">
            {breed.count} listings
          </p>
        </CardContent>
      </Card>
    </Link>
  )
}
