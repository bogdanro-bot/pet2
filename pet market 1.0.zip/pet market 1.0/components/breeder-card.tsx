'use client'

import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { MapPin, Star, ShieldCheck, Phone, PawPrint } from 'lucide-react'
import type { BreederProfile, User } from '@/lib/types'

interface BreederCardProps {
  breeder: BreederProfile & { user?: User }
}

export function BreederCard({ breeder }: BreederCardProps) {
  const user = breeder.user

  return (
    <Link href={`/breeders/${breeder.id}`}>
      <Card className="group overflow-hidden transition-all duration-300 hover:shadow-lg hover:-translate-y-1 border-border/50">
        {/* Header gradient */}
        <div className="relative h-24 bg-gradient-to-br from-primary to-primary/80">
          <Avatar className="absolute -bottom-8 left-4 h-20 w-20 border-4 border-background shadow-lg">
            <AvatarFallback className="bg-background text-primary text-2xl font-bold">
              {breeder.name.charAt(0)}
            </AvatarFallback>
          </Avatar>
          
          {/* Badges */}
          <div className="absolute right-4 top-4 flex gap-2">
            {breeder.isVip && (
              <Badge className="bg-warning text-warning-foreground">
                <Star className="mr-1 h-3 w-3" /> VIP
              </Badge>
            )}
            {user?.isVerified && (
              <Badge className="bg-accent text-accent-foreground">
                <ShieldCheck className="mr-1 h-3 w-3" /> Проверен
              </Badge>
            )}
          </div>
        </div>

        <CardContent className="pt-12 pb-6 px-4">
          <h3 className="mb-1 text-lg font-semibold text-foreground group-hover:text-primary line-clamp-1">
            {breeder.name}
          </h3>

          <div className="mb-3 flex items-center gap-1 text-sm text-muted-foreground">
            <MapPin className="h-3.5 w-3.5" />
            {user?.city || 'Местоположение не указано'}
          </div>

          {/* Rating */}
          <div className="mb-3 flex items-center gap-2">
            <div className="flex items-center gap-1 text-warning">
              <Star className="h-4 w-4 fill-current" />
              <span className="font-medium">{user?.rating?.toFixed(1) || '0.0'}</span>
            </div>
            <span className="text-sm text-muted-foreground">
              ({breeder.reviewsCount || 0} отзывов)
            </span>
          </div>

          <p className="mb-4 text-sm text-muted-foreground line-clamp-2">
            {breeder.description}
          </p>

          {/* Stats */}
          <div className="mb-4 flex gap-4 text-center">
            <div className="flex-1 rounded-lg bg-secondary/50 p-2">
              <div className="text-lg font-bold text-foreground">{breeder.animalsCount || 0}</div>
              <div className="text-xs text-muted-foreground">Питомцев</div>
            </div>
            <div className="flex-1 rounded-lg bg-secondary/50 p-2">
              <div className="text-lg font-bold text-foreground">{breeder.experience}</div>
              <div className="text-xs text-muted-foreground">Лет опыта</div>
            </div>
          </div>

          {/* Specializations */}
          {breeder.specializations && breeder.specializations.length > 0 && (
            <div className="mb-4 flex flex-wrap gap-1">
              {breeder.specializations.slice(0, 3).map((spec) => (
                <Badge key={spec} variant="outline" className="text-xs">
                  <PawPrint className="mr-1 h-3 w-3" />
                  {spec}
                </Badge>
              ))}
              {breeder.specializations.length > 3 && (
                <Badge variant="outline" className="text-xs">
                  +{breeder.specializations.length - 3}
                </Badge>
              )}
            </div>
          )}

          <Button 
            className="w-full" 
            variant="outline"
            onClick={(e) => {
              e.preventDefault()
              // Handle contact
            }}
          >
            <Phone className="mr-2 h-4 w-4" />
            Связаться
          </Button>
        </CardContent>
      </Card>
    </Link>
  )
}
