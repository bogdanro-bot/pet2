'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Search, Dog, Cat, MapPin } from 'lucide-react'

const cities = ['Москва', 'Санкт-Петербург', 'Казань', 'Новосибирск', 'Екатеринбург']

export function SearchHero() {
  const router = useRouter()
  const [petType, setPetType] = useState<string>('')
  const [city, setCity] = useState<string>('')
  const [search, setSearch] = useState('')

  const handleSearch = () => {
    const params = new URLSearchParams()
    if (petType) params.set('type', petType)
    if (city) params.set('city', city)
    if (search) params.set('search', search)
    router.push(`/catalog?${params.toString()}`)
  }

  return (
    <section className="relative overflow-hidden bg-primary py-20 md:py-28">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute left-[10%] top-[20%] h-64 w-64 rounded-full bg-white blur-3xl" />
        <div className="absolute right-[10%] bottom-[20%] h-48 w-48 rounded-full bg-white blur-3xl" />
      </div>

      <div className="container relative mx-auto px-4">
        <div className="mx-auto max-w-3xl text-center">
          <h1 className="mb-4 text-4xl font-bold tracking-tight text-primary-foreground md:text-5xl lg:text-6xl">
            Найдите идеального питомца
          </h1>
          <p className="mb-8 text-lg text-primary-foreground/80 md:text-xl">
            Более 10 000 проверенных питомцев от надежных заводчиков по всей стране
          </p>

          {/* Search Form */}
          <div className="rounded-2xl bg-background/95 p-4 shadow-2xl backdrop-blur-sm md:p-6">
            <div className="flex flex-col gap-3 md:flex-row">
              {/* Pet Type */}
              <Select value={petType} onValueChange={setPetType}>
                <SelectTrigger className="h-12 flex-1 border-border/50 bg-background">
                  <div className="flex items-center gap-2">
                    {petType === 'DOG' ? <Dog className="h-4 w-4 text-muted-foreground" /> : 
                     petType === 'CAT' ? <Cat className="h-4 w-4 text-muted-foreground" /> : null}
                    <SelectValue placeholder="Тип питомца" />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="DOG">
                    <div className="flex items-center gap-2">
                      <Dog className="h-4 w-4" /> Собаки
                    </div>
                  </SelectItem>
                  <SelectItem value="CAT">
                    <div className="flex items-center gap-2">
                      <Cat className="h-4 w-4" /> Кошки
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>

              {/* City */}
              <Select value={city} onValueChange={setCity}>
                <SelectTrigger className="h-12 flex-1 border-border/50 bg-background">
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <SelectValue placeholder="Город" />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  {cities.map((c) => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Search Input */}
              <div className="relative flex-[2]">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Поиск по породе, характеристикам..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                  className="h-12 border-border/50 bg-background pl-10"
                />
              </div>

              {/* Search Button */}
              <Button size="lg" className="h-12 px-8" onClick={handleSearch}>
                <Search className="mr-2 h-4 w-4" />
                Найти
              </Button>
            </div>
          </div>

          {/* Quick stats */}
          <div className="mt-8 flex flex-wrap justify-center gap-8 text-primary-foreground/80">
            <div className="text-center">
              <div className="text-2xl font-bold text-primary-foreground">10 000+</div>
              <div className="text-sm">Активных объявлений</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-primary-foreground">500+</div>
              <div className="text-sm">Проверенных заводчиков</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-primary-foreground">50+</div>
              <div className="text-sm">Доступных пород</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
