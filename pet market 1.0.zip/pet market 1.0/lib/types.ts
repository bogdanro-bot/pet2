// ============= ENUMS =============

export type UserRole = 'BUYER' | 'BREEDER' | 'ADMIN'
export type PetType = 'DOG' | 'CAT'
export type PetClass = 'PET' | 'BREED' | 'SHOW'
export type Gender = 'MALE' | 'FEMALE'
export type ListingStatus = 'ACTIVE' | 'SOLD' | 'ARCHIVED' | 'PENDING'
export type BonusType = 'BOOST' | 'VIP'

// ============= USER =============

export interface User {
  id: string
  email: string
  name: string
  phone?: string
  avatar?: string
  city?: string
  role: UserRole
  isVerified: boolean
  rating: number
  createdAt: Date
  updatedAt: Date
}

export interface BreederProfile {
  id: string
  userId: string
  name: string
  description: string
  address?: string
  workHours?: string
  experience: number
  isVip: boolean
  vipExpiresAt?: Date
  specializations: string[]
  certificates: string[]
  createdAt: Date
  updatedAt: Date
  // Relations
  user?: User
  animalsCount?: number
  reviewsCount?: number
}

// ============= PET =============

export interface Pet {
  id: string
  title: string
  description: string
  type: PetType
  breed: string
  price: number
  age: number
  gender: Gender
  petClass: PetClass
  city: string
  // Health & Documents
  hasPedigree: boolean
  hasVaccination: boolean
  hasHealthTests: boolean
  healthDetails?: string
  // Status & Promotion
  status: ListingStatus
  isVip: boolean
  vipExpiresAt?: Date
  isBoosted: boolean
  boostedUntil?: Date
  views: number
  // Timestamps
  createdAt: Date
  updatedAt: Date
  // Relations
  userId: string
  user?: User
  media?: Media[]
}

export interface Media {
  id: string
  url: string
  type: 'image' | 'video'
  isPrimary: boolean
  petId: string
}

// ============= REVIEW =============

export interface Review {
  id: string
  rating: number
  comment: string
  authorId: string
  targetId: string
  createdAt: Date
  author?: User
}

// ============= BREED =============

export interface Breed {
  id: string
  name: string
  slug: string
  type: PetType
  description?: string
  imageUrl?: string
  count?: number
}

// ============= BONUS & INVITE =============

export interface Bonus {
  id: string
  userId: string
  type: BonusType
  value: number
  usedValue: number
  expiresAt: Date
  createdAt: Date
}

export interface Invite {
  id: string
  code: string
  email: string
  type: 'private' | 'breeder'
  senderId: string
  receiverId?: string
  status: 'pending' | 'accepted' | 'expired'
  createdAt: Date
  acceptedAt?: Date
}

// ============= API RESPONSES =============

export interface PaginatedResponse<T> {
  items: T[]
  total: number
  page: number
  totalPages: number
}

export interface ApiError {
  error: string
  message?: string
}

// ============= FILTER & SEARCH =============

export interface PetFilters {
  type?: PetType
  breed?: string
  city?: string
  priceMin?: number
  priceMax?: number
  gender?: Gender
  petClass?: PetClass
  hasPedigree?: boolean
  hasVaccination?: boolean
  sort?: 'newest' | 'price_asc' | 'price_desc' | 'popular'
  page?: number
  limit?: number
  search?: string
}

export interface BreederFilters {
  city?: string
  isVerified?: boolean
  isVip?: boolean
  specialization?: string
  sort?: 'rating' | 'experience' | 'newest'
}
