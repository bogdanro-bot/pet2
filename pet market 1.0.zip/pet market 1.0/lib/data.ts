import type { Pet, User, BreederProfile, Review, Breed, Bonus, PetFilters, PaginatedResponse } from './types'

// ============= MOCK DATA =============

export const users: User[] = [
  {
    id: '1',
    email: 'anna@example.com',
    name: 'Anna Petrova',
    phone: '+7 (999) 123-45-67',
    avatar: null,
    city: 'Moscow',
    role: 'BREEDER',
    isVerified: true,
    rating: 4.8,
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date(),
  },
  {
    id: '2',
    email: 'ivan@example.com',
    name: 'Ivan Sidorov',
    phone: '+7 (999) 234-56-78',
    avatar: null,
    city: 'Saint Petersburg',
    role: 'BREEDER',
    isVerified: true,
    rating: 4.5,
    createdAt: new Date('2024-02-01'),
    updatedAt: new Date(),
  },
]

export const breederProfiles: BreederProfile[] = [
  {
    id: '1',
    userId: '1',
    name: 'Happy Paws Kennel',
    description: 'We have been breeding Pomeranians and Labradors for 10 years. All pets come with documents and vaccinations. Our kennel is certified and inspected regularly.',
    address: '123 Example Street, Moscow',
    workHours: 'Daily, 10:00 - 20:00',
    experience: 10,
    isVip: true,
    specializations: ['Pomeranian', 'Labrador', 'Golden Retriever'],
    certificates: [],
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date(),
    animalsCount: 5,
    reviewsCount: 15,
  },
  {
    id: '2',
    userId: '2',
    name: 'Royal Cats Cattery',
    description: 'Breeding Maine Coons and British Shorthairs for over 5 years. Champion bloodlines available.',
    address: '45 Nevsky Prospect, Saint Petersburg',
    workHours: 'Mon-Sat, 11:00 - 19:00',
    experience: 5,
    isVip: false,
    specializations: ['Maine Coon', 'British Shorthair'],
    certificates: [],
    createdAt: new Date('2024-02-01'),
    updatedAt: new Date(),
    animalsCount: 3,
    reviewsCount: 8,
  },
]

export const pets: Pet[] = [
  {
    id: '1',
    title: 'Adorable Pomeranian Puppy',
    description: 'Beautiful Pomeranian puppy, fully vaccinated with all documents. Very playful and friendly, great with children.',
    type: 'DOG',
    breed: 'Pomeranian',
    price: 25000,
    age: 2,
    gender: 'MALE',
    petClass: 'PET',
    city: 'Moscow',
    hasPedigree: true,
    hasVaccination: true,
    hasHealthTests: true,
    healthDetails: 'Complete health check, vaccinated against rabies and distemper',
    status: 'ACTIVE',
    isVip: true,
    views: 145,
    createdAt: new Date('2024-03-01'),
    updatedAt: new Date(),
    userId: '1',
    media: [{ id: '1', url: '/placeholder.svg', type: 'image', isPrimary: true, petId: '1' }],
  },
  {
    id: '2',
    title: 'Maine Coon Kitten',
    description: 'Stunning Maine Coon kitten with champion bloodline. Very affectionate and intelligent.',
    type: 'CAT',
    breed: 'Maine Coon',
    price: 35000,
    age: 3,
    gender: 'FEMALE',
    petClass: 'BREED',
    city: 'Saint Petersburg',
    hasPedigree: true,
    hasVaccination: true,
    hasHealthTests: true,
    status: 'ACTIVE',
    isVip: false,
    views: 89,
    createdAt: new Date('2024-03-05'),
    updatedAt: new Date(),
    userId: '2',
    media: [{ id: '2', url: '/placeholder.svg', type: 'image', isPrimary: true, petId: '2' }],
  },
  {
    id: '3',
    title: 'Golden Retriever Puppy',
    description: 'Friendly Golden Retriever puppy looking for a loving home. Great family dog.',
    type: 'DOG',
    breed: 'Golden Retriever',
    price: 30000,
    age: 4,
    gender: 'MALE',
    petClass: 'PET',
    city: 'Moscow',
    hasPedigree: true,
    hasVaccination: true,
    hasHealthTests: false,
    status: 'ACTIVE',
    isVip: true,
    views: 203,
    createdAt: new Date('2024-03-10'),
    updatedAt: new Date(),
    userId: '1',
    media: [{ id: '3', url: '/placeholder.svg', type: 'image', isPrimary: true, petId: '3' }],
  },
  {
    id: '4',
    title: 'British Shorthair Kitten',
    description: 'Cute British Shorthair kitten, blue color. Very calm and cuddly.',
    type: 'CAT',
    breed: 'British Shorthair',
    price: 20000,
    age: 2,
    gender: 'MALE',
    petClass: 'PET',
    city: 'Saint Petersburg',
    hasPedigree: false,
    hasVaccination: true,
    hasHealthTests: false,
    status: 'ACTIVE',
    isVip: false,
    views: 67,
    createdAt: new Date('2024-03-12'),
    updatedAt: new Date(),
    userId: '2',
    media: [{ id: '4', url: '/placeholder.svg', type: 'image', isPrimary: true, petId: '4' }],
  },
  {
    id: '5',
    title: 'Husky Puppy with Blue Eyes',
    description: 'Beautiful Siberian Husky with stunning blue eyes. Very energetic and smart.',
    type: 'DOG',
    breed: 'Husky',
    price: 40000,
    age: 3,
    gender: 'FEMALE',
    petClass: 'SHOW',
    city: 'Kazan',
    hasPedigree: true,
    hasVaccination: true,
    hasHealthTests: true,
    healthDetails: 'DNA tested, hip and eye clearances',
    status: 'ACTIVE',
    isVip: true,
    views: 312,
    createdAt: new Date('2024-03-15'),
    updatedAt: new Date(),
    userId: '1',
    media: [{ id: '5', url: '/placeholder.svg', type: 'image', isPrimary: true, petId: '5' }],
  },
  {
    id: '6',
    title: 'Labrador Puppy',
    description: 'Sweet Labrador puppy, chocolate color. Very trainable and loving.',
    type: 'DOG',
    breed: 'Labrador',
    price: 18000,
    age: 5,
    gender: 'MALE',
    petClass: 'PET',
    city: 'Moscow',
    hasPedigree: false,
    hasVaccination: true,
    hasHealthTests: false,
    status: 'ACTIVE',
    isVip: false,
    views: 98,
    createdAt: new Date('2024-03-18'),
    updatedAt: new Date(),
    userId: '1',
    media: [{ id: '6', url: '/placeholder.svg', type: 'image', isPrimary: true, petId: '6' }],
  },
]

export const reviews: Review[] = [
  {
    id: '1',
    rating: 5,
    comment: 'Excellent breeder! The puppy is healthy and exactly as described. Very professional.',
    authorId: '2',
    targetId: '1',
    createdAt: new Date('2024-03-01'),
    author: users[1],
  },
  {
    id: '2',
    rating: 4,
    comment: 'Good experience overall. The kitten is lovely and well-socialized.',
    authorId: '1',
    targetId: '2',
    createdAt: new Date('2024-03-05'),
    author: users[0],
  },
]

export const breeds: Breed[] = [
  { id: '1', name: 'Pomeranian', slug: 'pomeranian', type: 'DOG', count: 12 },
  { id: '2', name: 'Labrador', slug: 'labrador', type: 'DOG', count: 18 },
  { id: '3', name: 'Golden Retriever', slug: 'golden-retriever', type: 'DOG', count: 15 },
  { id: '4', name: 'Husky', slug: 'husky', type: 'DOG', count: 8 },
  { id: '5', name: 'Maine Coon', slug: 'maine-coon', type: 'CAT', count: 10 },
  { id: '6', name: 'British Shorthair', slug: 'british-shorthair', type: 'CAT', count: 14 },
  { id: '7', name: 'German Shepherd', slug: 'german-shepherd', type: 'DOG', count: 9 },
  { id: '8', name: 'French Bulldog', slug: 'french-bulldog', type: 'DOG', count: 11 },
]

export const bonuses: Bonus[] = [
  {
    id: '1',
    userId: '1',
    type: 'BOOST',
    value: 3,
    usedValue: 0,
    expiresAt: new Date('2025-06-01'),
    createdAt: new Date(),
  },
  {
    id: '2',
    userId: '1',
    type: 'VIP',
    value: 7,
    usedValue: 0,
    expiresAt: new Date('2025-06-01'),
    createdAt: new Date(),
  },
]

// ============= DATA FUNCTIONS =============

export function getPets(filters: PetFilters = {}): PaginatedResponse<Pet> {
  let result = [...pets]

  // Apply filters
  if (filters.type) {
    result = result.filter(p => p.type === filters.type)
  }
  if (filters.breed) {
    result = result.filter(p => p.breed.toLowerCase().includes(filters.breed!.toLowerCase()))
  }
  if (filters.city) {
    result = result.filter(p => p.city.toLowerCase().includes(filters.city!.toLowerCase()))
  }
  if (filters.priceMin) {
    result = result.filter(p => p.price >= filters.priceMin!)
  }
  if (filters.priceMax) {
    result = result.filter(p => p.price <= filters.priceMax!)
  }
  if (filters.gender) {
    result = result.filter(p => p.gender === filters.gender)
  }
  if (filters.petClass) {
    result = result.filter(p => p.petClass === filters.petClass)
  }
  if (filters.hasPedigree !== undefined) {
    result = result.filter(p => p.hasPedigree === filters.hasPedigree)
  }
  if (filters.hasVaccination !== undefined) {
    result = result.filter(p => p.hasVaccination === filters.hasVaccination)
  }
  if (filters.search) {
    const search = filters.search.toLowerCase()
    result = result.filter(p =>
      p.title.toLowerCase().includes(search) ||
      p.breed.toLowerCase().includes(search) ||
      p.city.toLowerCase().includes(search) ||
      p.description.toLowerCase().includes(search)
    )
  }

  // Apply sorting
  switch (filters.sort) {
    case 'price_asc':
      result.sort((a, b) => a.price - b.price)
      break
    case 'price_desc':
      result.sort((a, b) => b.price - a.price)
      break
    case 'popular':
      result.sort((a, b) => b.views - a.views)
      break
    case 'newest':
    default:
      result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
  }

  // VIP listings first
  result.sort((a, b) => (b.isVip ? 1 : 0) - (a.isVip ? 1 : 0))

  // Pagination
  const page = filters.page || 1
  const limit = filters.limit || 8
  const total = result.length
  const totalPages = Math.ceil(total / limit)
  const start = (page - 1) * limit
  const items = result.slice(start, start + limit)

  // Attach user data
  const itemsWithUser = items.map(pet => ({
    ...pet,
    user: users.find(u => u.id === pet.userId),
  }))

  return {
    items: itemsWithUser,
    total,
    page,
    totalPages,
  }
}

export function getPetById(id: string): (Pet & { user?: User }) | undefined {
  const pet = pets.find(p => p.id === id)
  if (!pet) return undefined
  return {
    ...pet,
    user: users.find(u => u.id === pet.userId),
  }
}

export function getBreeders(): (BreederProfile & { user?: User })[] {
  return breederProfiles.map(profile => ({
    ...profile,
    user: users.find(u => u.id === profile.userId),
    animalsCount: pets.filter(p => p.userId === profile.userId).length,
    reviewsCount: reviews.filter(r => r.targetId === profile.userId).length,
  }))
}

export function getBreederById(id: string): (BreederProfile & { user?: User; animals: Pet[]; reviews: Review[] }) | undefined {
  const profile = breederProfiles.find(p => p.id === id)
  if (!profile) return undefined
  
  return {
    ...profile,
    user: users.find(u => u.id === profile.userId),
    animals: pets.filter(p => p.userId === profile.userId),
    reviews: reviews.filter(r => r.targetId === profile.userId),
  }
}

export function getPopularBreeds(): Breed[] {
  return breeds.slice(0, 6)
}

export function getUserById(id: string): User | undefined {
  return users.find(u => u.id === id)
}

export function getReviewsByUserId(userId: string): Review[] {
  return reviews.filter(r => r.targetId === userId)
}
