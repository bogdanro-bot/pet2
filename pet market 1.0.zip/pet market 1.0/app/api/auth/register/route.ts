// app/api/auth/register/route.ts
import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { prisma } from '@/lib/prisma';
import { UserRole } from '@prisma/client';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, password, name, phone, city, role } = body;
    
    if (!email || !password || !name) {
      return NextResponse.json({ error: 'Email, пароль и имя обязательны' }, { status: 400 });
    }
    
    const existingUser = await prisma.user.findUnique({
      where: { email },
    });
    
    if (existingUser) {
      return NextResponse.json({ error: 'Пользователь уже существует' }, { status: 400 });
    }
    
    const hashedPassword = await bcrypt.hash(password, 10);
    
    const userRole = role === 'breeder' ? UserRole.BREEDER : UserRole.BUYER;
    
    const user = await prisma.user.create({
      data: {
        email,
        passwordHash: hashedPassword,
        name,
        phone,
        city,
        role: userRole,
        ...(role === 'breeder' && {
          breederProfile: {
            create: {
              name: name,
              description: '',
              experience: 0,
              specializations: [],
              certificates: [],
            },
          },
        }),
      },
    });
    
    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
      },
    });
  } catch (error) {
    console.error('Ошибка регистрации:', error);
    return NextResponse.json({ error: 'Ошибка сервера' }, { status: 500 });
  }
}