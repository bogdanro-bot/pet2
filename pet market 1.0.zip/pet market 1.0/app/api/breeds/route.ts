import { NextResponse } from 'next/server'
import { getPopularBreeds } from '@/lib/data'

export async function GET() {
  const breeds = getPopularBreeds()
  return NextResponse.json(breeds)
}
