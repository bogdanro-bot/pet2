import { NextResponse } from 'next/server'
import { getBreeders } from '@/lib/data'

export async function GET() {
  const breeders = getBreeders()
  return NextResponse.json(breeders)
}
