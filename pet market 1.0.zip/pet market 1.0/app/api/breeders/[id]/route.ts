import { NextRequest, NextResponse } from 'next/server'
import { getBreederById } from '@/lib/data'

type RouteParams = Promise<{ id: string }>

export async function GET(
  request: NextRequest,
  { params }: { params: RouteParams }
) {
  const { id } = await params
  const breeder = getBreederById(id)

  if (!breeder) {
    return NextResponse.json(
      { error: 'Breeder not found' },
      { status: 404 }
    )
  }

  return NextResponse.json(breeder)
}
