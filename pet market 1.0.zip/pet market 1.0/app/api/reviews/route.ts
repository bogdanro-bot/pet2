import { NextRequest, NextResponse } from 'next/server'
import { getReviewsByUserId, users } from '@/lib/data'

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const userId = searchParams.get('userId')

  if (!userId) {
    return NextResponse.json(
      { error: 'userId is required' },
      { status: 400 }
    )
  }

  const reviews = getReviewsByUserId(userId)
  return NextResponse.json(reviews)
}

export async function POST(request: NextRequest) {
  try {
    const { toUserId, rating, comment } = await request.json()

    if (!toUserId || !rating || !comment) {
      return NextResponse.json(
        { error: 'toUserId, rating, and comment are required' },
        { status: 400 }
      )
    }

    if (rating < 1 || rating > 5) {
      return NextResponse.json(
        { error: 'Rating must be between 1 and 5' },
        { status: 400 }
      )
    }

    // In a real app, this would save to the database
    const newReview = {
      id: Date.now().toString(),
      toUserId,
      fromUserId: '1', // Would come from session
      rating: parseInt(rating),
      comment,
      authorName: users.find(u => u.id === '1')?.name || 'User',
      createdAt: new Date(),
    }

    return NextResponse.json(newReview, { status: 201 })
  } catch {
    return NextResponse.json(
      { error: 'Invalid request body' },
      { status: 400 }
    )
  }
}
