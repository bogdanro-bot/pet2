// app/api/animals/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/prisma';
import { authOptions } from '@/lib/auth';
import { PetType, Gender, PetClass, ListingStatus } from '@prisma/client';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Не авторизован' }, { status: 401 });
    }
    
    const body = await request.json();
    const { 
      title, 
      description, 
      type, 
      breed, 
      price, 
      age, 
      gender, 
      petClass, 
      city, 
      hasPedigree, 
      hasVaccination, 
      hasHealthTests,
      healthDetails,
      photos 
    } = body;
    
    // Валидация
    if (!title || !breed || !price || !city) {
      return NextResponse.json({ error: 'Заполните обязательные поля' }, { status: 400 });
    }
    
    if (!photos || photos.length === 0) {
      return NextResponse.json({ error: 'Добавьте хотя бы одно фото' }, { status: 400 });
    }
    
    // Получаем пользователя
    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    });
    
    if (!user) {
      return NextResponse.json({ error: 'Пользователь не найден' }, { status: 404 });
    }
    
    // Создаем объявление
    const pet = await prisma.pet.create({
      data: {
        title,
        description: description || '',
        type: type === 'DOG' ? PetType.DOG : PetType.CAT,
        breed,
        price: parseInt(price),
        age: parseInt(age) || 0,
        gender: gender === 'MALE' ? Gender.MALE : Gender.FEMALE,
        petClass: petClass === 'PET' ? PetClass.PET : petClass === 'BREED' ? PetClass.BREED : PetClass.SHOW,
        city,
        hasPedigree: hasPedigree || false,
        hasVaccination: hasVaccination || false,
        hasHealthTests: hasHealthTests || false,
        healthDetails: healthDetails || null,
        status: ListingStatus.ACTIVE,
        userId: user.id,
        media: {
          create: photos.map((url: string, index: number) => ({
            url,
            type: 'image',
            isPrimary: index === 0,
          })),
        },
      },
      include: {
        media: true,
        user: {
          select: { name: true, rating: true, city: true },
        },
      },
    });
    
    return NextResponse.json({ success: true, pet });
  } catch (error) {
    console.error('Ошибка создания объявления:', error);
    return NextResponse.json({ error: 'Ошибка сервера' }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '9');
    const page = parseInt(searchParams.get('page') || '1');
    const breed = searchParams.get('breed');
    const city = searchParams.get('city');
    const type = searchParams.get('type');
    const sort = searchParams.get('sort') || 'newest';
    
    const where: any = { status: ListingStatus.ACTIVE };
    
    if (breed && breed !== 'all') {
      where.breed = { contains: breed, mode: 'insensitive' };
    }
    
    if (city && city !== 'all') {
      where.city = { contains: city, mode: 'insensitive' };
    }
    
    if (type && type !== 'all') {
      where.type = type === 'DOG' ? PetType.DOG : PetType.CAT;
    }
    
    let orderBy: any = {};
    if (sort === 'newest') {
      orderBy = { createdAt: 'desc' };
    } else if (sort === 'price_asc') {
      orderBy = { price: 'asc' };
    } else if (sort === 'price_desc') {
      orderBy = { price: 'desc' };
    } else if (sort === 'popular') {
      orderBy = { views: 'desc' };
    } else if (sort === 'vip_first') {
      orderBy = [{ isVip: 'desc' }, { createdAt: 'desc' }];
    }
    
    const [pets, total] = await Promise.all([
      prisma.pet.findMany({
        where,
        include: {
          media: true,
          user: {
            select: { name: true, rating: true, city: true },
          },
        },
        orderBy,
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.pet.count({ where }),
    ]);
    
    return NextResponse.json({
      items: pets,
      total,
      page,
      totalPages: Math.ceil(total / limit),
    });
  } catch (error) {
    console.error('Ошибка получения объявлений:', error);
    return NextResponse.json({ error: 'Ошибка сервера' }, { status: 500 });
  }
}