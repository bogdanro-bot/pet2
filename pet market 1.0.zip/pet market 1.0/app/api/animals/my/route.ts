// app/api/animals/my/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/prisma';
import { authOptions } from '@/lib/auth';
import { ListingStatus } from '@prisma/client';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Не авторизован' }, { status: 401 });
    }
    
    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    });
    
    if (!user) {
      return NextResponse.json({ error: 'Пользователь не найден' }, { status: 404 });
    }
    
    const pets = await prisma.pet.findMany({
      where: { userId: user.id },
      include: {
        media: true,
      },
      orderBy: { createdAt: 'desc' },
    });
    
    return NextResponse.json(pets);
  } catch (error) {
    console.error('Ошибка получения объявлений:', error);
    return NextResponse.json({ error: 'Ошибка сервера' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Не авторизован' }, { status: 401 });
    }
    
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    
    if (!id) {
      return NextResponse.json({ error: 'ID не указан' }, { status: 400 });
    }
    
    const pet = await prisma.pet.findUnique({
      where: { id },
      include: { user: true },
    });
    
    if (!pet) {
      return NextResponse.json({ error: 'Объявление не найдено' }, { status: 404 });
    }
    
    if (pet.user.email !== session.user.email) {
      return NextResponse.json({ error: 'Нет доступа' }, { status: 403 });
    }
    
    // Мягкое удаление - меняем статус на ARCHIVED
    await prisma.pet.update({
      where: { id },
      data: { status: ListingStatus.ARCHIVED },
    });
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Ошибка удаления:', error);
    return NextResponse.json({ error: 'Ошибка сервера' }, { status: 500 });
  }
}