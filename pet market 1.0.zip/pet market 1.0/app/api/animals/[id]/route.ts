import { NextRequest, NextResponse } from 'next/server'
import { getPetById } from '@/lib/data'

type RouteParams = Promise<{ id: string }>

export async function GET(
  request: NextRequest,
  { params }: { params: RouteParams }
) {
  const { id } = await params
  const pet = getPetById(id)

  if (!pet) {
    return NextResponse.json(
      { error: 'Pet not found' },
      { status: 404 }
    )
  }

  // Increment views (in real app, this would update the database)
  const petWithViews = {
    ...pet,
    views: pet.views + 1,
  }

  return NextResponse.json(petWithViews)
}

export async function PUT(
  request: NextRequest,
  { params }: { params: RouteParams }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const pet = getPetById(id)

    if (!pet) {
      return NextResponse.json(
        { error: 'Pet not found' },
        { status: 404 }
      )
    }

    // In real app, update database
    const updatedPet = {
      ...pet,
      ...body,
      updatedAt: new Date(),
    }

    return NextResponse.json(updatedPet)
  } catch {
    return NextResponse.json(
      { error: 'Invalid request body' },
      { status: 400 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: RouteParams }
) {
  const { id } = await params
  const pet = getPetById(id)

  if (!pet) {
    return NextResponse.json(
      { error: 'Pet not found' },
      { status: 404 }
    )
  }

  // In real app, delete from database
  return NextResponse.json({ success: true, message: 'Pet deleted successfully' })
}
