import { NextRequest, NextResponse } from 'next/server'
import { bonuses } from '@/lib/data'

export async function GET() {
  // Return invite stats for the current user
  const stats = {
    total_invites: 2,
    accepted_invites: 1,
    breeder_invites: 0,
    private_invites: 1,
  }

  const achievements = [
    {
      id: 1,
      achievement_type: 'first_invite',
      reward_type: 'boost',
      reward_value: 1,
      achieved_at: new Date().toISOString(),
    },
  ]

  const referralCode = 'REF' + Math.random().toString(36).substr(2, 6).toUpperCase()

  return NextResponse.json({
    stats,
    bonuses,
    achievements,
    referral_code: referralCode,
  })
}

export async function POST(request: NextRequest) {
  try {
    const { email, type } = await request.json()

    if (!email) {
      return NextResponse.json(
        { error: 'Email is required' },
        { status: 400 }
      )
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Invalid email format' },
        { status: 400 }
      )
    }

    // Generate invite code
    const inviteCode = 'INVITE' + Math.random().toString(36).substr(2, 8).toUpperCase()

    // In a real app, this would:
    // 1. Create an invite record in the database
    // 2. Send an email to the invitee
    // 3. Track the referral

    const reward = type === 'breeder' 
      ? { boosts: 3, vipDays: 7 }
      : { boosts: 1, vipDays: 0 }

    return NextResponse.json({
      success: true,
      message: `Invitation sent to ${email}!`,
      code: inviteCode,
      reward,
    })
  } catch {
    return NextResponse.json(
      { error: 'Invalid request body' },
      { status: 400 }
    )
  }
}
