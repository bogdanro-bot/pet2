import type { Metadata } from 'next'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { BreederCard } from '@/components/breeder-card'
import { getBreeders } from '@/lib/data'
import { ShieldCheck, Star, Award } from 'lucide-react'

export const metadata: Metadata = {
  title: 'Проверенные заводчики',
  description: 'Найдите надежных и проверенных заводчиков питомцев с отличными отзывами и сертификатами.',
}

export default function BreedersPage() {
  const breeders = getBreeders()

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-primary py-16 md:py-24">
          <div className="container mx-auto px-4 text-center">
            <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-primary-foreground/10">
              <Award className="h-8 w-8 text-primary-foreground" />
            </div>
            <h1 className="mb-4 text-3xl font-bold text-primary-foreground md:text-4xl lg:text-5xl">
              Проверенные заводчики
            </h1>
            <p className="mx-auto max-w-2xl text-primary-foreground/80">
              Все наши заводчики проходят тщательную проверку. Просматривайте профили надежных 
              профессионалов с подтвержденным опытом и отличными отзывами.
            </p>
          </div>
        </section>

        {/* Features */}
        <section className="border-b border-border bg-card py-8">
          <div className="container mx-auto px-4">
            <div className="flex flex-wrap justify-center gap-8 text-center">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-accent/10">
                  <ShieldCheck className="h-5 w-5 text-accent" />
                </div>
                <div className="text-left">
                  <div className="font-semibold text-foreground">Проверенные</div>
                  <div className="text-sm text-muted-foreground">Все заводчики проверены</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-warning/10">
                  <Star className="h-5 w-5 text-warning" />
                </div>
                <div className="text-left">
                  <div className="font-semibold text-foreground">С рейтингом</div>
                  <div className="text-sm text-muted-foreground">Реальные отзывы покупателей</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                  <Award className="h-5 w-5 text-primary" />
                </div>
                <div className="text-left">
                  <div className="font-semibold text-foreground">Сертифицированные</div>
                  <div className="text-sm text-muted-foreground">Профессиональные питомники</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Breeders Grid */}
        <section className="bg-secondary/20 py-12 md:py-16">
          <div className="container mx-auto px-4">
            <div className="mb-8 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-foreground">Все заводчики</h2>
                <p className="text-muted-foreground">{breeders.length} проверенных заводчиков</p>
              </div>
            </div>

            {breeders.length > 0 ? (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {breeders.map((breeder) => (
                  <BreederCard key={breeder.id} breeder={breeder} />
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border py-16 text-center">
                <div className="mb-4 text-6xl">&#127968;</div>
                <h3 className="mb-2 text-xl font-semibold">Пока нет заводчиков</h3>
                <p className="text-muted-foreground">
                  Станьте первым зарегистрированным проверенным заводчиком
                </p>
              </div>
            )}
          </div>
        </section>

        {/* CTA Section */}
        <section className="bg-card py-12 md:py-16">
          <div className="container mx-auto px-4 text-center">
            <h2 className="mb-4 text-2xl font-bold text-foreground md:text-3xl">
              Вы заводчик?
            </h2>
            <p className="mx-auto mb-6 max-w-xl text-muted-foreground">
              Присоединяйтесь к нашей платформе и охватите тысячи потенциальных покупателей. 
              Получите статус проверенного и завоюйте доверие клиентов.
            </p>
            <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
              <a
                href="/dashboard"
                className="inline-flex items-center justify-center rounded-lg bg-primary px-6 py-3 font-medium text-primary-foreground transition-colors hover:bg-primary/90"
              >
                Зарегистрироваться как заводчик
              </a>
              <a
                href="#"
                className="inline-flex items-center justify-center rounded-lg border border-border px-6 py-3 font-medium text-foreground transition-colors hover:bg-secondary"
              >
                Узнать больше
              </a>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
