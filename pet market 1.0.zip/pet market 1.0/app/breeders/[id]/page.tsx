import type { Metadata } from 'next'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { PetCard } from '@/components/pet-card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import { 
  MapPin, Phone, Mail, Clock, Star, ShieldCheck, 
  Calendar, ChevronLeft, PawPrint, MessageCircle, Award
} from 'lucide-react'
import { getBreederById } from '@/lib/data'

type PageParams = Promise<{ id: string }>

export async function generateMetadata({ params }: { params: PageParams }): Promise<Metadata> {
  const { id } = await params
  const breeder = getBreederById(id)
  
  if (!breeder) {
    return { title: 'Заводчик не найден' }
  }

  return {
    title: breeder.name,
    description: breeder.description,
  }
}

export default async function BreederDetailPage({ params }: { params: PageParams }) {
  const { id } = await params
  const breeder = getBreederById(id)

  if (!breeder) {
    notFound()
  }

  const user = breeder.user

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('ru-RU', {
      year: 'numeric',
      month: 'long',
    }).format(new Date(date))
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      
      <main className="flex-1 bg-secondary/20 py-8">
        <div className="container mx-auto px-4">
          {/* Breadcrumb */}
          <div className="mb-6">
            <Link 
              href="/breeders" 
              className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground"
            >
              <ChevronLeft className="mr-1 h-4 w-4" />
              Назад к заводчикам
            </Link>
          </div>

          {/* Breeder Header */}
          <Card className="mb-8 overflow-hidden">
            {/* Cover */}
            <div className="relative h-32 bg-gradient-to-br from-primary to-primary/80 md:h-48">
              {/* Badges */}
              <div className="absolute right-4 top-4 flex gap-2">
                {breeder.isVip && (
                  <Badge className="bg-warning text-warning-foreground">
                    <Star className="mr-1 h-3 w-3" /> VIP-заводчик
                  </Badge>
                )}
                {user?.isVerified && (
                  <Badge className="bg-accent text-accent-foreground">
                    <ShieldCheck className="mr-1 h-3 w-3" /> Проверен
                  </Badge>
                )}
              </div>
            </div>

            <CardContent className="relative pb-6">
              {/* Avatar */}
              <Avatar className="absolute -top-12 left-6 h-24 w-24 border-4 border-background shadow-lg md:-top-16 md:h-32 md:w-32">
                <AvatarFallback className="bg-background text-primary text-3xl font-bold md:text-4xl">
                  {breeder.name.charAt(0)}
                </AvatarFallback>
              </Avatar>

              <div className="ml-0 pt-14 md:ml-40 md:pt-0">
                <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
                  <div>
                    <h1 className="mb-2 text-2xl font-bold text-foreground md:text-3xl">
                      {breeder.name}
                    </h1>
                    <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <MapPin className="h-4 w-4" />
                        {user?.city || 'Местоположение не указано'}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        На сайте с {formatDate(breeder.createdAt)}
                      </span>
                      <span className="flex items-center gap-1">
                        <Award className="h-4 w-4" />
                        {breeder.experience} лет опыта
                      </span>
                    </div>

                    {/* Rating */}
                    <div className="mt-3 flex items-center gap-2">
                      <div className="flex items-center gap-1 text-warning">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star
                            key={i}
                            className={`h-5 w-5 ${
                              i < Math.round(user?.rating || 0)
                                ? 'fill-current'
                                : 'fill-none stroke-warning'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="font-medium">{user?.rating?.toFixed(1) || '0.0'}</span>
                      <span className="text-muted-foreground">
                        ({breeder.reviews.length} отзывов)
                      </span>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button>
                      <Phone className="mr-2 h-4 w-4" />
                      Позвонить
                    </Button>
                    <Button variant="outline">
                      <MessageCircle className="mr-2 h-4 w-4" />
                      Написать
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid gap-8 lg:grid-cols-3">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* About */}
              <Card>
                <CardHeader>
                  <CardTitle>О заводчике</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="whitespace-pre-wrap text-muted-foreground leading-relaxed">
                    {breeder.description}
                  </p>

                  {/* Specializations */}
                  {breeder.specializations && breeder.specializations.length > 0 && (
                    <div className="mt-6">
                      <h4 className="mb-3 font-medium text-foreground">Специализации</h4>
                      <div className="flex flex-wrap gap-2">
                        {breeder.specializations.map((spec) => (
                          <Badge key={spec} variant="secondary" className="px-3 py-1">
                            <PawPrint className="mr-1 h-3 w-3" />
                            {spec}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Active Listings */}
              <Card>
                <CardHeader>
                  <CardTitle>Активные объявления ({breeder.animals.length})</CardTitle>
                </CardHeader>
                <CardContent>
                  {breeder.animals.length > 0 ? (
                    <div className="grid gap-4 sm:grid-cols-2">
                      {breeder.animals.map((pet) => (
                        <PetCard key={pet.id} pet={pet} variant="compact" />
                      ))}
                    </div>
                  ) : (
                    <p className="text-center text-muted-foreground py-8">
                      На данный момент нет активных объявлений
                    </p>
                  )}
                </CardContent>
              </Card>

              {/* Reviews */}
              <Card>
                <CardHeader>
                  <CardTitle>Отзывы ({breeder.reviews.length})</CardTitle>
                </CardHeader>
                <CardContent>
                  {breeder.reviews.length > 0 ? (
                    <div className="space-y-4">
                      {breeder.reviews.map((review) => (
                        <div key={review.id} className="rounded-lg border border-border p-4">
                          <div className="mb-2 flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Avatar className="h-8 w-8">
                                <AvatarFallback className="text-xs">
                                  {review.author?.name.charAt(0) || 'U'}
                                </AvatarFallback>
                              </Avatar>
                              <span className="font-medium text-foreground">
                                {review.author?.name || 'Аноним'}
                              </span>
                            </div>
                            <div className="flex items-center gap-1 text-warning">
                              {Array.from({ length: 5 }).map((_, i) => (
                                <Star
                                  key={i}
                                  className={`h-4 w-4 ${
                                    i < review.rating ? 'fill-current' : 'fill-none stroke-warning'
                                  }`}
                                />
                              ))}
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground">{review.comment}</p>
                          <p className="mt-2 text-xs text-muted-foreground">
                            {new Intl.DateTimeFormat('ru-RU', {
                              year: 'numeric',
                              month: 'short',
                              day: 'numeric',
                            }).format(new Date(review.createdAt))}
                          </p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-center text-muted-foreground py-8">
                      Пока нет отзывов
                    </p>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Contact Info */}
              <Card className="lg:sticky lg:top-24">
                <CardHeader>
                  <CardTitle>Контактная информация</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {user?.phone && (
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                        <Phone className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Телефон</div>
                        <div className="font-medium">{user.phone}</div>
                      </div>
                    </div>
                  )}

                  {user?.email && (
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                        <Mail className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Email</div>
                        <div className="font-medium">{user.email}</div>
                      </div>
                    </div>
                  )}

                  {breeder.address && (
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                        <MapPin className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Адрес</div>
                        <div className="font-medium">{breeder.address}</div>
                      </div>
                    </div>
                  )}

                  {breeder.workHours && (
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                        <Clock className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Часы работы</div>
                        <div className="font-medium">{breeder.workHours}</div>
                      </div>
                    </div>
                  )}

                  <Separator />

                  <Button className="w-full" size="lg">
                    <Phone className="mr-2 h-4 w-4" />
                    Показать номер телефона
                  </Button>
                  <Button variant="outline" className="w-full" size="lg">
                    <MessageCircle className="mr-2 h-4 w-4" />
                    Написать сообщение
                  </Button>
                </CardContent>
              </Card>

              {/* Trust Score */}
              <Card className="border-accent/20 bg-accent/5">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ShieldCheck className="h-5 w-5 text-accent" />
                    Рейтинг доверия
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="mb-4 text-center">
                    <div className="text-4xl font-bold text-accent">
                      {Math.round((user?.rating || 0) * 20)}%
                    </div>
                    <div className="text-sm text-muted-foreground">Подтвержденный уровень доверия</div>
                  </div>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center gap-2 text-muted-foreground">
                      <ShieldCheck className="h-4 w-4 text-accent" />
                      Личность подтверждена
                    </li>
                    <li className="flex items-center gap-2 text-muted-foreground">
                      <ShieldCheck className="h-4 w-4 text-accent" />
                      {breeder.reviews.length}+ положительных отзывов
                    </li>
                    <li className="flex items-center gap-2 text-muted-foreground">
                      <ShieldCheck className="h-4 w-4 text-accent" />
                      {breeder.experience} лет опыта
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
