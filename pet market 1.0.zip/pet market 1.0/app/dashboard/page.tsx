import type { Metadata } from 'next'
import Link from 'next/link'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { 
  PawPrint, Eye, Star, Gift, Plus, ArrowRight, 
  TrendingUp, Users, Rocket
} from 'lucide-react'
import { pets, bonuses } from '@/lib/data'

export const metadata: Metadata = {
  title: 'Личный кабинет',
  description: 'Управляйте объявлениями о питомцах, просматривайте статистику и настраивайте аккаунт.',
}

// Mock stats
const stats = {
  totalPets: pets.filter(p => p.userId === '1').length,
  totalViews: pets.filter(p => p.userId === '1').reduce((sum, p) => sum + p.views, 0),
  activeBonuses: bonuses.length,
  referrals: 2,
}

const recentPets = pets.filter(p => p.userId === '1').slice(0, 3)

export default function DashboardPage() {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground md:text-3xl">Личный кабинет</h1>
          <p className="text-muted-foreground">С возвращением! Вот что происходит.</p>
        </div>
        <Button asChild>
          <Link href="/dashboard/pets">
            <Plus className="mr-2 h-4 w-4" />
            Добавить питомца
          </Link>
        </Button>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <PawPrint className="h-6 w-6 text-primary" />
              </div>
              <div>
                <div className="text-2xl font-bold text-foreground">{stats.totalPets}</div>
                <div className="text-sm text-muted-foreground">Активных объявлений</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-accent/10">
                <Eye className="h-6 w-6 text-accent" />
              </div>
              <div>
                <div className="text-2xl font-bold text-foreground">{stats.totalViews}</div>
                <div className="text-sm text-muted-foreground">Всего просмотров</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-warning/10">
                <Gift className="h-6 w-6 text-warning" />
              </div>
              <div>
                <div className="text-2xl font-bold text-foreground">{stats.activeBonuses}</div>
                <div className="text-sm text-muted-foreground">Активных бонусов</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-chart-4/10">
                <Users className="h-6 w-6 text-chart-4" />
              </div>
              <div>
                <div className="text-2xl font-bold text-foreground">{stats.referrals}</div>
                <div className="text-sm text-muted-foreground">Рефералов</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Recent Listings */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Последние объявления</CardTitle>
            <Button variant="ghost" size="sm" asChild>
              <Link href="/dashboard/pets">
                Смотреть все
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentPets.map((pet) => (
                <div
                  key={pet.id}
                  className="flex items-center justify-between rounded-lg border border-border p-3"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-secondary text-2xl">
                      {pet.type === 'DOG' ? '&#128021;' : '&#128008;'}
                    </div>
                    <div>
                      <div className="font-medium text-foreground">{pet.title}</div>
                      <div className="text-sm text-muted-foreground">
                        {pet.breed} &bull; {pet.price.toLocaleString('ru-RU')} &#8381;
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {pet.isVip && (
                      <Badge className="bg-warning text-warning-foreground">
                        <Star className="mr-1 h-3 w-3" /> VIP
                      </Badge>
                    )}
                    <div className="flex items-center gap-1 text-sm text-muted-foreground">
                      <Eye className="h-4 w-4" />
                      {pet.views}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Быстрые действия</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Link
              href="/dashboard/pets"
              className="flex items-center gap-4 rounded-lg border border-border p-4 transition-colors hover:bg-secondary/50"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <Plus className="h-6 w-6 text-primary" />
              </div>
              <div className="flex-1">
                <div className="font-medium text-foreground">Добавить объявление</div>
                <div className="text-sm text-muted-foreground">Создать новое объявление о питомце</div>
              </div>
              <ArrowRight className="h-5 w-5 text-muted-foreground" />
            </Link>

            <Link
              href="/dashboard/boost"
              className="flex items-center gap-4 rounded-lg border border-border p-4 transition-colors hover:bg-secondary/50"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-warning/10">
                <Rocket className="h-6 w-6 text-warning" />
              </div>
              <div className="flex-1">
                <div className="font-medium text-foreground">Поднять объявления</div>
                <div className="text-sm text-muted-foreground">Увеличить видимость</div>
              </div>
              <ArrowRight className="h-5 w-5 text-muted-foreground" />
            </Link>

            <Link
              href="/dashboard/referrals"
              className="flex items-center gap-4 rounded-lg border border-border p-4 transition-colors hover:bg-secondary/50"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-accent/10">
                <Gift className="h-6 w-6 text-accent" />
              </div>
              <div className="flex-1">
                <div className="font-medium text-foreground">Пригласить друзей</div>
                <div className="text-sm text-muted-foreground">Получить бесплатные поднятия</div>
              </div>
              <ArrowRight className="h-5 w-5 text-muted-foreground" />
            </Link>

            <Link
              href="/dashboard/stats"
              className="flex items-center gap-4 rounded-lg border border-border p-4 transition-colors hover:bg-secondary/50"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-chart-2/10">
                <TrendingUp className="h-6 w-6 text-chart-2" />
              </div>
              <div className="flex-1">
                <div className="font-medium text-foreground">Посмотреть статистику</div>
                <div className="text-sm text-muted-foreground">Отслеживать эффективность</div>
              </div>
              <ArrowRight className="h-5 w-5 text-muted-foreground" />
            </Link>
          </CardContent>
        </Card>
      </div>

      {/* Available Bonuses */}
      {bonuses.length > 0 && (
        <Card className="border-warning/20 bg-warning/5">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Gift className="h-5 w-5 text-warning" />
              Доступные бонусы
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-2">
              {bonuses.map((bonus) => (
                <div
                  key={bonus.id}
                  className="flex items-center justify-between rounded-lg bg-background p-4 shadow-sm"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-warning/10">
                      {bonus.type === 'BOOST' ? (
                        <Rocket className="h-5 w-5 text-warning" />
                      ) : (
                        <Star className="h-5 w-5 text-warning" />
                      )}
                    </div>
                    <div>
                      <div className="font-medium text-foreground">
                        {bonus.type === 'BOOST' ? 'Поднятия объявлений' : 'Дни VIP'}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Осталось {bonus.value - bonus.usedValue}
                      </div>
                    </div>
                  </div>
                  <Button size="sm" variant="outline">
                    Использовать
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
