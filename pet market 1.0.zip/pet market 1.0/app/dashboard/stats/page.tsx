import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { 
  Eye, Users, TrendingUp, PawPrint, Phone, MessageCircle, BarChart3
} from 'lucide-react'
import { pets } from '@/lib/data'

const userPets = pets.filter(p => p.userId === '1')

// Mock analytics data
const stats = {
  totalViews: userPets.reduce((sum, p) => sum + p.views, 0),
  totalListings: userPets.length,
  activeListings: userPets.filter(p => p.status === 'ACTIVE').length,
  phoneViews: 23,
  messages: 8,
  favorites: 15,
}

const viewsData = [
  { day: 'Mon', views: 45 },
  { day: 'Tue', views: 62 },
  { day: 'Wed', views: 38 },
  { day: 'Thu', views: 71 },
  { day: 'Fri', views: 55 },
  { day: 'Sat', views: 89 },
  { day: 'Sun', views: 67 },
]

const maxViews = Math.max(...viewsData.map(d => d.views))

export default function StatsPage() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground md:text-3xl">Statistics</h1>
        <p className="text-muted-foreground">Track your listing performance</p>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <Eye className="h-6 w-6 text-primary" />
              </div>
              <div>
                <div className="text-2xl font-bold text-foreground">{stats.totalViews}</div>
                <div className="text-sm text-muted-foreground">Total Views</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-accent/10">
                <PawPrint className="h-6 w-6 text-accent" />
              </div>
              <div>
                <div className="text-2xl font-bold text-foreground">{stats.activeListings}</div>
                <div className="text-sm text-muted-foreground">Active Listings</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-chart-2/10">
                <Phone className="h-6 w-6 text-chart-2" />
              </div>
              <div>
                <div className="text-2xl font-bold text-foreground">{stats.phoneViews}</div>
                <div className="text-sm text-muted-foreground">Phone Views</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-chart-4/10">
                <MessageCircle className="h-6 w-6 text-chart-4" />
              </div>
              <div>
                <div className="text-2xl font-bold text-foreground">{stats.messages}</div>
                <div className="text-sm text-muted-foreground">Messages</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-destructive/10">
                <Users className="h-6 w-6 text-destructive" />
              </div>
              <div>
                <div className="text-2xl font-bold text-foreground">{stats.favorites}</div>
                <div className="text-sm text-muted-foreground">Saved by Users</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-warning/10">
                <TrendingUp className="h-6 w-6 text-warning" />
              </div>
              <div>
                <div className="flex items-center gap-1 text-2xl font-bold text-accent">
                  +12%
                </div>
                <div className="text-sm text-muted-foreground">vs Last Week</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Views Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Views This Week
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex h-64 items-end gap-2">
            {viewsData.map((data) => (
              <div key={data.day} className="flex flex-1 flex-col items-center gap-2">
                <div className="relative flex w-full items-end justify-center">
                  <div
                    className="w-full max-w-12 rounded-t bg-primary transition-all hover:bg-primary/80"
                    style={{ height: `${(data.views / maxViews) * 200}px` }}
                  />
                </div>
                <div className="text-sm font-medium text-foreground">{data.views}</div>
                <div className="text-xs text-muted-foreground">{data.day}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Per-Listing Stats */}
      <Card>
        <CardHeader>
          <CardTitle>Listing Performance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {userPets.map((pet) => (
              <div
                key={pet.id}
                className="flex items-center justify-between rounded-lg border border-border p-4"
              >
                <div className="flex items-center gap-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-secondary text-2xl">
                    {pet.type === 'DOG' ? '🐕' : '🐈'}
                  </div>
                  <div>
                    <div className="font-medium text-foreground">{pet.title}</div>
                    <div className="text-sm text-muted-foreground">
                      {pet.breed} &bull; ${pet.price.toLocaleString()}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-6 text-sm">
                  <div className="text-center">
                    <div className="font-medium text-foreground">{pet.views}</div>
                    <div className="text-muted-foreground">Views</div>
                  </div>
                  <div className="text-center">
                    <div className="font-medium text-foreground">
                      {Math.floor(pet.views * 0.15)}
                    </div>
                    <div className="text-muted-foreground">Contacts</div>
                  </div>
                  <div className="text-center">
                    <div className="font-medium text-foreground">
                      {(pet.views * 0.15 / pet.views * 100).toFixed(1)}%
                    </div>
                    <div className="text-muted-foreground">CTR</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
