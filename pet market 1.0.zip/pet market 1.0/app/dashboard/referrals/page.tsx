'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { 
  Gift, Users, Rocket, Star, Copy, Send, 
  CheckCircle2, Trophy, Sparkles
} from 'lucide-react'
import { bonuses } from '@/lib/data'

// Mock referral data
const referralCode = 'ANNA2024'
const referralStats = {
  total: 2,
  accepted: 1,
  pending: 1,
}

const achievements = [
  { id: 1, title: 'Первый реферал', description: 'Пригласите первого друга', reward: '1 поднятие', unlocked: true },
  { id: 2, title: 'Команда растет', description: 'Пригласите 5 друзей', reward: '3 поднятия + 7 дней VIP', unlocked: false },
  { id: 3, title: 'Амбассадор', description: 'Пригласите 10 друзей', reward: '10 поднятий + 30 дней VIP', unlocked: false },
]

export default function ReferralsPage() {
  const [email, setEmail] = useState('')
  const [inviteType, setInviteType] = useState<'private' | 'breeder'>('private')
  const [copied, setCopied] = useState(false)
  const [sending, setSending] = useState(false)

  const copyCode = () => {
    navigator.clipboard.writeText(referralCode)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const sendInvite = async () => {
    if (!email) {
      alert('Пожалуйста, введите email адрес')
      return
    }
    setSending(true)
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000))
    setSending(false)
    alert(`Приглашение отправлено на ${email}!`)
    setEmail('')
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground md:text-3xl">Реферальная программа</h1>
        <p className="text-muted-foreground">Приглашайте друзей и получайте награды</p>
      </div>

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-3">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <div>
                <div className="text-2xl font-bold text-foreground">{referralStats.total}</div>
                <div className="text-sm text-muted-foreground">Всего приглашений</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-accent/10">
                <CheckCircle2 className="h-6 w-6 text-accent" />
              </div>
              <div>
                <div className="text-2xl font-bold text-foreground">{referralStats.accepted}</div>
                <div className="text-sm text-muted-foreground">Принято</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-warning/10">
                <Gift className="h-6 w-6 text-warning" />
              </div>
              <div>
                <div className="text-2xl font-bold text-foreground">{bonuses.length}</div>
                <div className="text-sm text-muted-foreground">Заработано бонусов</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Send Invite */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Send className="h-5 w-5" />
              Отправить приглашение
            </CardTitle>
            <CardDescription>
              Приглашайте друзей и получайте бонусы, когда они присоединятся
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Invite Type */}
            <div className="flex gap-2">
              <Button
                variant={inviteType === 'private' ? 'default' : 'outline'}
                className="flex-1"
                onClick={() => setInviteType('private')}
              >
                <Users className="mr-2 h-4 w-4" />
                Частный продавец
              </Button>
              <Button
                variant={inviteType === 'breeder' ? 'default' : 'outline'}
                className="flex-1"
                onClick={() => setInviteType('breeder')}
              >
                <Trophy className="mr-2 h-4 w-4" />
                Заводчик
              </Button>
            </div>

            {/* Rewards Preview */}
            <div className="rounded-lg bg-secondary/50 p-3">
              <div className="text-sm font-medium text-foreground">
                Вы получите:
              </div>
              <div className="mt-1 text-sm text-muted-foreground">
                {inviteType === 'private' ? (
                  <span className="flex items-center gap-1">
                    <Rocket className="h-4 w-4 text-warning" />
                    1 поднятие объявления
                  </span>
                ) : (
                  <div className="space-y-1">
                    <span className="flex items-center gap-1">
                      <Rocket className="h-4 w-4 text-warning" />
                      3 поднятия объявлений
                    </span>
                    <span className="flex items-center gap-1">
                      <Star className="h-4 w-4 text-warning" />
                      7 дней VIP
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Email Input */}
            <div className="flex gap-2">
              <Input
                type="email"
                placeholder="friend@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-1"
              />
              <Button onClick={sendInvite} disabled={sending}>
                {sending ? 'Отправка...' : 'Отправить'}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Referral Code */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Gift className="h-5 w-5" />
              Ваш реферальный код
            </CardTitle>
            <CardDescription>
              Поделитесь этим кодом с друзьями
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="flex-1 rounded-lg border border-border bg-secondary/30 p-4 text-center">
                <span className="text-2xl font-bold tracking-wider text-foreground">
                  {referralCode}
                </span>
              </div>
              <Button variant="outline" size="icon" onClick={copyCode}>
                {copied ? (
                  <CheckCircle2 className="h-4 w-4 text-accent" />
                ) : (
                  <Copy className="h-4 w-4" />
                )}
              </Button>
            </div>

            <div className="rounded-lg bg-accent/10 p-4">
              <div className="flex items-center gap-2 text-sm font-medium text-accent">
                <Sparkles className="h-4 w-4" />
                Как это работает
              </div>
              <ul className="mt-2 space-y-1 text-sm text-muted-foreground">
                <li>1. Поделитесь кодом с друзьями</li>
                <li>2. Они регистрируются с вашим кодом</li>
                <li>3. Вы оба получаете награды!</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Achievements */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5" />
            Достижения
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-3">
            {achievements.map((achievement) => (
              <div
                key={achievement.id}
                className={`rounded-lg border p-4 ${
                  achievement.unlocked
                    ? 'border-accent bg-accent/5'
                    : 'border-border bg-secondary/30 opacity-60'
                }`}
              >
                <div className="mb-2 flex items-center gap-2">
                  {achievement.unlocked ? (
                    <CheckCircle2 className="h-5 w-5 text-accent" />
                  ) : (
                    <div className="h-5 w-5 rounded-full border-2 border-muted-foreground" />
                  )}
                  <span className="font-medium text-foreground">{achievement.title}</span>
                </div>
                <p className="mb-2 text-sm text-muted-foreground">
                  {achievement.description}
                </p>
                <Badge variant={achievement.unlocked ? 'default' : 'secondary'}>
                  {achievement.reward}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Active Bonuses */}
      {bonuses.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Gift className="h-5 w-5 text-warning" />
              Ваши бонусы
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-2">
              {bonuses.map((bonus) => (
                <div
                  key={bonus.id}
                  className="flex items-center justify-between rounded-lg border border-warning/20 bg-warning/5 p-4"
                >
                  <div className="flex items-center gap-3">
                    {bonus.type === 'BOOST' ? (
                      <Rocket className="h-8 w-8 text-warning" />
                    ) : (
                      <Star className="h-8 w-8 text-warning" />
                    )}
                    <div>
                      <div className="font-medium text-foreground">
                        {bonus.type === 'BOOST' ? 'Поднятия объявлений' : 'Дни VIP'}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {bonus.value - bonus.usedValue} / {bonus.value} осталось
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Истекает: {new Date(bonus.expiresAt).toLocaleDateString('ru-RU')}
                      </div>
                    </div>
                  </div>
                  <Button size="sm">Использовать</Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
