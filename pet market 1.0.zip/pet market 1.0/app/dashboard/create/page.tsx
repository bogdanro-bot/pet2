// app/dashboard/create/page.tsx
'use client';

import { useState, useRef, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { 
  Upload, 
  X, 
  ImageIcon, 
  Loader2,
  PawPrint,
  MapPin,
  DollarSign,
  Calendar,
  Heart,
  Info
} from 'lucide-react';

interface UploadedPhoto {
  file: File;
  preview: string;
  id: string;
}

export default function CreatePetPage() {
  const router = useRouter();
  const { data: session, status } = useSession();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [photos, setPhotos] = useState<UploadedPhoto[]>([]);
  const [formData, setFormData] = useState({
    title: '',
    type: 'DOG',
    breed: '',
    price: '',
    city: '',
    age: '',
    gender: 'MALE',
    petClass: 'PET',
    description: '',
    hasPedigree: false,
    hasVaccination: false,
    hasHealthTests: false,
    healthDetails: '',
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/login');
    }
  }, [status, router]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    
    if (photos.length + files.length > 10) {
      setError('Можно загрузить не более 10 фотографий');
      return;
    }
    
    const newPhotos: UploadedPhoto[] = files.map(file => ({
      file,
      preview: URL.createObjectURL(file),
      id: Math.random().toString(36).substring(7),
    }));
    
    setPhotos(prev => [...prev, ...newPhotos]);
    setError('');
  };

  const removePhoto = (id: string) => {
    const photoToRemove = photos.find(p => p.id === id);
    if (photoToRemove) {
      URL.revokeObjectURL(photoToRemove.preview);
    }
    setPhotos(prev => prev.filter(p => p.id !== id));
  };

  const uploadPhotos = async (): Promise<string[]> => {
    const uploadedUrls: string[] = [];
    
    for (const photo of photos) {
      const formData = new FormData();
      formData.append('file', photo.file);
      
      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });
      
      if (response.ok) {
        const data = await response.json();
        uploadedUrls.push(data.url);
      } else {
        throw new Error('Ошибка загрузки фото');
      }
    }
    
    return uploadedUrls;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    
    if (!formData.title.trim()) {
      setError('Введите название объявления');
      return;
    }
    
    if (!formData.breed.trim()) {
      setError('Введите породу');
      return;
    }
    
    if (!formData.price || parseInt(formData.price) <= 0) {
      setError('Введите корректную цену');
      return;
    }
    
    if (!formData.city.trim()) {
      setError('Введите город');
      return;
    }
    
    if (photos.length === 0) {
      setError('Добавьте хотя бы одно фото');
      return;
    }
    
    setLoading(true);
    setUploading(true);
    
    try {
      const photoUrls = await uploadPhotos();
      
      const response = await fetch('/api/animals', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          price: parseInt(formData.price),
          age: parseInt(formData.age) || 0,
          photos: photoUrls,
        }),
      });
      
      const data = await response.json();
      
      if (response.ok) {
        setSuccess('Объявление успешно создано!');
        setTimeout(() => {
          router.push('/dashboard/pets');
        }, 2000);
      } else {
        setError(data.error || 'Ошибка при создании объявления');
      }
    } catch (error) {
      console.error('Ошибка:', error);
      setError('Произошла ошибка при сохранении');
    } finally {
      setLoading(false);
      setUploading(false);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    const files = Array.from(e.dataTransfer.files).filter(
      file => file.type.startsWith('image/')
    );
    
    if (photos.length + files.length > 10) {
      setError('Можно загрузить не более 10 фотографий');
      return;
    }
    
    const newPhotos: UploadedPhoto[] = files.map(file => ({
      file,
      preview: URL.createObjectURL(file),
      id: Math.random().toString(36).substring(7),
    }));
    
    setPhotos(prev => [...prev, ...newPhotos]);
    setError('');
  };

  if (status === 'loading') {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold">Добавить объявление</h1>
        <p className="text-muted-foreground mt-1">
          Заполните информацию о питомце. Все поля со звездочкой обязательны для заполнения.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Фото */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ImageIcon className="h-5 w-5" />
              Фотографии
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div
              onClick={() => fileInputRef.current?.click()}
              onDragOver={handleDragOver}
              onDrop={handleDrop}
              className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center cursor-pointer hover:border-primary transition"
            >
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept="image/*"
                onChange={handleFileSelect}
                className="hidden"
              />
              <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">Нажмите или перетащите фото сюда</p>
              <p className="text-sm text-gray-400 mt-1">
                Можно загрузить до 10 фото. Форматы: JPG, PNG, GIF
              </p>
            </div>
            
            {photos.length > 0 && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                {photos.map((photo, index) => (
                  <div key={photo.id} className="relative group">
                    <img
                      src={photo.preview}
                      alt={`Фото ${index + 1}`}
                      className="w-full h-32 object-cover rounded-lg"
                    />
                    {index === 0 && (
                      <Badge className="absolute top-2 left-2 bg-blue-500">
                        Главное
                      </Badge>
                    )}
                    <button
                      type="button"
                      onClick={() => removePhoto(photo.id)}
                      className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Основная информация */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PawPrint className="h-5 w-5" />
              Основная информация
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="title" className="required">
                Название объявления
              </Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({...formData, title: e.target.value})}
                placeholder="Например: Щенок шпица, мальчик, 2 месяца"
                className="mt-1.5"
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="type">Тип питомца</Label>
                <Select
                  value={formData.type}
                  onValueChange={(value) => setFormData({...formData, type: value})}
                >
                  <SelectTrigger className="mt-1.5">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="DOG">🐕 Собака</SelectItem>
                    <SelectItem value="CAT">🐈 Кошка</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="breed" className="required">
                  Порода
                </Label>
                <Input
                  id="breed"
                  value={formData.breed}
                  onChange={(e) => setFormData({...formData, breed: e.target.value})}
                  placeholder="Шпиц, Лабрадор, Мейн-кун..."
                  className="mt-1.5"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="price" className="required">
                  Цена (₽)
                </Label>
                <div className="relative mt-1.5">
                  <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    id="price"
                    type="number"
                    value={formData.price}
                    onChange={(e) => setFormData({...formData, price: e.target.value})}
                    placeholder="25000"
                    className="pl-9"
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="city" className="required">
                  Город
                </Label>
                <div className="relative mt-1.5">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    id="city"
                    value={formData.city}
                    onChange={(e) => setFormData({...formData, city: e.target.value})}
                    placeholder="Москва"
                    className="pl-9"
                  />
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="age">Возраст (месяцев)</Label>
                <div className="relative mt-1.5">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    id="age"
                    type="number"
                    value={formData.age}
                    onChange={(e) => setFormData({...formData, age: e.target.value})}
                    placeholder="2"
                    className="pl-9"
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="gender">Пол</Label>
                <Select
                  value={formData.gender}
                  onValueChange={(value) => setFormData({...formData, gender: value})}
                >
                  <SelectTrigger className="mt-1.5">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="MALE">🐕 Мальчик</SelectItem>
                    <SelectItem value="FEMALE">🐕‍🦺 Девочка</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div>
              <Label htmlFor="petClass">Класс питомца</Label>
              <Select
                value={formData.petClass}
                onValueChange={(value) => setFormData({...formData, petClass: value})}
              >
                <SelectTrigger className="mt-1.5">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="PET">PET-класс (домашний питомец)</SelectItem>
                  <SelectItem value="BREED">BRID-класс (для разведения)</SelectItem>
                  <SelectItem value="SHOW">SHOW-класс (для выставок)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Описание */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Info className="h-5 w-5" />
              Описание
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              rows={6}
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              placeholder="Расскажите о питомце: характер, привычки, здоровье, почему продаете..."
              className="mt-1.5"
            />
          </CardContent>
        </Card>

        {/* Документы и здоровье */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Heart className="h-5 w-5" />
              Документы и здоровье
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.hasPedigree}
                onChange={(e) => setFormData({...formData, hasPedigree: e.target.checked})}
                className="w-4 h-4 rounded border-gray-300"
              />
              <span className="text-sm">Есть родословная</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.hasVaccination}
                onChange={(e) => setFormData({...formData, hasVaccination: e.target.checked})}
                className="w-4 h-4 rounded border-gray-300"
              />
              <span className="text-sm">Сделаны прививки по возрасту</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.hasHealthTests}
                onChange={(e) => setFormData({...formData, hasHealthTests: e.target.checked})}
                className="w-4 h-4 rounded border-gray-300"
              />
              <span className="text-sm">Пройдены тесты здоровья</span>
            </label>
            
            {formData.hasHealthTests && (
              <div className="mt-3">
                <Label>Детали здоровья</Label>
                <Textarea
                  rows={3}
                  value={formData.healthDetails}
                  onChange={(e) => setFormData({...formData, healthDetails: e.target.value})}
                  placeholder="Результаты тестов, обследований..."
                  className="mt-1.5"
                />
              </div>
            )}
          </CardContent>
        </Card>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700">
            {error}
          </div>
        )}
        
        {success && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-green-700">
            {success}
          </div>
        )}

        <div className="flex gap-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => router.back()}
            className="flex-1"
          >
            Отмена
          </Button>
          <Button
            type="submit"
            disabled={loading}
            className="flex-1 bg-blue-600 hover:bg-blue-700"
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Публикация...
              </>
            ) : (
              'Опубликовать объявление'
            )}
          </Button>
        </div>
      </form>
    </div>
  );
}