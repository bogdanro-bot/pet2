// app/dashboard/pets/page.tsx
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Plus, 
  Edit, 
  TrendingUp, 
  Trash2, 
  Eye,
  MapPin,
  Calendar
} from 'lucide-react';
import Link from 'next/link';
import { useSession } from 'next-auth/react';

interface Pet {
  id: string;
  title: string;
  breed: string;
  price: number;
  city: string;
  age: number;
  gender: string;
  description: string;
  isVip: boolean;
  views: number;
  status: string;
  media: { url: string; isPrimary: boolean }[];
  createdAt: string;
}

export default function MyPetsPage() {
  const router = useRouter();
  const { data: session, status } = useSession();
  const [pets, setPets] = useState<Pet[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/login');
    }
  }, [status, router]);

  useEffect(() => {
    if (session) {
      loadPets();
    }
  }, [session]);

  const loadPets = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/animals/my');
      if (response.ok) {
        const data = await response.json();
        setPets(data);
      } else {
        console.error('Ошибка загрузки');
      }
    } catch (error) {
      console.error('Ошибка:', error);
    } finally {
      setLoading(false);
    }
  };

  const deletePet = async (id: string) => {
    if (!confirm('Вы уверены, что хотите удалить объявление?')) return;
    
    try {
      const response = await fetch(`/api/animals/my?id=${id}`, {
        method: 'DELETE',
      });
      
      if (response.ok) {
        setPets(pets.filter(pet => pet.id !== id));
      } else {
        alert('Ошибка при удалении');
      }
    } catch (error) {
      console.error('Ошибка:', error);
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('ru-RU').format(price);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('ru-RU');
  };

  if (status === 'loading' || loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold">Мои питомцы</h1>
          <p className="text-muted-foreground mt-1">
            Управление объявлениями о питомцах
          </p>
        </div>
        <Link href="/dashboard/create">
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Добавить питомца
          </Button>
        </Link>
      </div>

      {pets.length === 0 ? (
        <Card className="text-center py-12">
          <CardContent>
            <div className="text-6xl mb-4">🐕</div>
            <h3 className="text-lg font-semibold mb-2">У вас пока нет питомцев</h3>
            <p className="text-muted-foreground mb-4">
              Добавьте первого питомца, чтобы начать продажу
            </p>
            <Link href="/dashboard/create">
              <Button>Добавить питомца</Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6">
          {pets.map((pet) => (
            <Card key={pet.id} className="overflow-hidden hover:shadow-lg transition">
              <div className="flex flex-col md:flex-row">
                {/* Фото */}
                <div className="md:w-48 h-48 bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center text-4xl relative">
                  {pet.media?.find(m => m.isPrimary)?.url ? (
                    <img
                      src={pet.media.find(m => m.isPrimary)?.url}
                      alt={pet.title}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    pet.gender === 'MALE' ? '🐕' : '🐕‍🦺'
                  )}
                  {pet.isVip && (
                    <Badge className="absolute top-2 right-2 bg-yellow-500">
                      ⭐ VIP
                    </Badge>
                  )}
                </div>
                
                {/* Информация */}
                <div className="flex-1 p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="text-xl font-bold">{pet.title}</h3>
                      <p className="text-muted-foreground">
                        {pet.breed} - {pet.age} {getAgeText(pet.age)}
                      </p>
                      <p className="text-2xl font-bold text-blue-600 mt-2">
                        {formatPrice(pet.price)} ₽
                      </p>
                      <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <MapPin className="h-4 w-4" />
                          {pet.city}
                        </span>
                        <span className="flex items-center gap-1">
                          <Eye className="h-4 w-4" />
                          {pet.views} просмотров
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="h-4 w-4" />
                          {formatDate(pet.createdAt)}
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => router.push(`/dashboard/pets/${pet.id}/edit`)}
                        className="gap-1"
                      >
                        <Edit className="h-4 w-4" />
                        Изменить
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-1 text-green-600 border-green-600 hover:bg-green-50"
                      >
                        <TrendingUp className="h-4 w-4" />
                        Поднять
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => deletePet(pet.id)}
                        className="gap-1 text-red-600 border-red-600 hover:bg-red-50"
                      >
                        <Trash2 className="h-4 w-4" />
                        Удалить
                      </Button>
                    </div>
                  </div>
                  
                  {/* Статус */}
                  <div className="mt-3">
                    <Badge variant={pet.status === 'ACTIVE' ? 'default' : 'secondary'}>
                      {pet.status === 'ACTIVE' ? 'Активно' : 'Архивировано'}
                    </Badge>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

function getAgeText(age: number): string {
  if (age === 0) return 'новорожденный';
  if (age === 1) return 'месяц';
  if (age >= 2 && age <= 4) return 'месяца';
  return 'месяцев';
}