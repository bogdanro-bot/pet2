import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { 
  Rocket, Star, Zap, Crown, TrendingUp, Eye, CheckCircle2
} from 'lucide-react'

const boostPackages = [
  {
    id: 'boost-1',
    name: 'Single Boost',
    description: 'Boost one listing for 24 hours',
    price: 5,
    features: ['24h visibility boost', 'Top of search results', 'Highlighted listing'],
    popular: false,
  },
  {
    id: 'boost-3',
    name: 'Power Pack',
    description: 'Best value for active sellers',
    price: 12,
    originalPrice: 15,
    features: ['3 listing boosts', '48h visibility each', 'Priority support', 'Analytics dashboard'],
    popular: true,
  },
  {
    id: 'boost-10',
    name: 'Pro Pack',
    description: 'For professional breeders',
    price: 35,
    originalPrice: 50,
    features: ['10 listing boosts', '72h visibility each', 'VIP badge (7 days)', 'Featured on homepage'],
    popular: false,
  },
]

const vipPackages = [
  {
    id: 'vip-7',
    name: '7 Day VIP',
    description: 'Try VIP features',
    price: 15,
    days: 7,
    features: ['VIP badge on all listings', 'Priority in search', 'Unlimited boosts', 'Direct messaging'],
  },
  {
    id: 'vip-30',
    name: '30 Day VIP',
    description: 'Most popular choice',
    price: 45,
    originalPrice: 60,
    days: 30,
    features: ['All 7-day features', 'Featured breeder profile', 'Analytics & insights', 'Dedicated support'],
    popular: true,
  },
  {
    id: 'vip-90',
    name: '90 Day VIP',
    description: 'Best value for pros',
    price: 99,
    originalPrice: 135,
    days: 90,
    features: ['All 30-day features', 'Homepage spotlight', 'Custom profile badge', 'Priority listing review'],
  },
]

export default function BoostPage() {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground md:text-3xl">Boost & VIP</h1>
        <p className="text-muted-foreground">Increase visibility and sell faster</p>
      </div>

      {/* Stats Preview */}
      <Card className="border-primary/20 bg-primary/5">
        <CardContent className="p-6">
          <div className="flex flex-wrap items-center justify-center gap-8">
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 text-3xl font-bold text-foreground">
                <TrendingUp className="h-8 w-8 text-primary" />
                3x
              </div>
              <div className="text-sm text-muted-foreground">More Views</div>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 text-3xl font-bold text-foreground">
                <Eye className="h-8 w-8 text-accent" />
                5x
              </div>
              <div className="text-sm text-muted-foreground">More Contacts</div>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 text-3xl font-bold text-foreground">
                <Zap className="h-8 w-8 text-warning" />
                70%
              </div>
              <div className="text-sm text-muted-foreground">Faster Sales</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Boost Packages */}
      <div>
        <h2 className="mb-4 text-xl font-semibold text-foreground flex items-center gap-2">
          <Rocket className="h-5 w-5 text-warning" />
          Listing Boosts
        </h2>
        <div className="grid gap-4 md:grid-cols-3">
          {boostPackages.map((pkg) => (
            <Card 
              key={pkg.id} 
              className={`relative overflow-hidden ${
                pkg.popular ? 'border-primary ring-2 ring-primary/20' : ''
              }`}
            >
              {pkg.popular && (
                <div className="absolute right-0 top-0 bg-primary px-3 py-1 text-xs font-medium text-primary-foreground">
                  Popular
                </div>
              )}
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Rocket className="h-5 w-5 text-warning" />
                  {pkg.name}
                </CardTitle>
                <CardDescription>{pkg.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  <span className="text-3xl font-bold text-foreground">${pkg.price}</span>
                  {pkg.originalPrice && (
                    <span className="ml-2 text-sm text-muted-foreground line-through">
                      ${pkg.originalPrice}
                    </span>
                  )}
                </div>
                <ul className="mb-6 space-y-2">
                  {pkg.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <CheckCircle2 className="h-4 w-4 text-accent" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Button className="w-full" variant={pkg.popular ? 'default' : 'outline'}>
                  Get Started
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* VIP Packages */}
      <div>
        <h2 className="mb-4 text-xl font-semibold text-foreground flex items-center gap-2">
          <Crown className="h-5 w-5 text-warning" />
          VIP Membership
        </h2>
        <div className="grid gap-4 md:grid-cols-3">
          {vipPackages.map((pkg) => (
            <Card 
              key={pkg.id} 
              className={`relative overflow-hidden ${
                pkg.popular ? 'border-warning ring-2 ring-warning/20' : ''
              }`}
            >
              {pkg.popular && (
                <div className="absolute right-0 top-0 bg-warning px-3 py-1 text-xs font-medium text-warning-foreground">
                  Best Value
                </div>
              )}
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Star className="h-5 w-5 text-warning" />
                    {pkg.name}
                  </CardTitle>
                  <Badge variant="secondary">{pkg.days} days</Badge>
                </div>
                <CardDescription>{pkg.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  <span className="text-3xl font-bold text-foreground">${pkg.price}</span>
                  {pkg.originalPrice && (
                    <span className="ml-2 text-sm text-muted-foreground line-through">
                      ${pkg.originalPrice}
                    </span>
                  )}
                </div>
                <ul className="mb-6 space-y-2">
                  {pkg.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <CheckCircle2 className="h-4 w-4 text-warning" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Button 
                  className={`w-full ${pkg.popular ? 'bg-warning text-warning-foreground hover:bg-warning/90' : ''}`}
                  variant={pkg.popular ? 'default' : 'outline'}
                >
                  Upgrade to VIP
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* FAQ */}
      <Card>
        <CardHeader>
          <CardTitle>Frequently Asked Questions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h4 className="font-medium text-foreground">What is a listing boost?</h4>
            <p className="text-sm text-muted-foreground">
              A boost places your listing at the top of search results and highlights it for increased visibility.
            </p>
          </div>
          <div>
            <h4 className="font-medium text-foreground">How long does a boost last?</h4>
            <p className="text-sm text-muted-foreground">
              Boosts last 24-72 hours depending on the package. VIP members get unlimited boosts.
            </p>
          </div>
          <div>
            <h4 className="font-medium text-foreground">Can I cancel my VIP subscription?</h4>
            <p className="text-sm text-muted-foreground">
              Yes, you can cancel anytime. Your benefits will remain active until the end of your billing period.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
