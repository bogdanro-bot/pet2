import Link from 'next/link'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { SearchHero } from '@/components/search-hero'
import { PetCard } from '@/components/pet-card'
import { BreedCard } from '@/components/breed-card'
import { FeaturesSection } from '@/components/features-section'
import { Button } from '@/components/ui/button'
import { ArrowRight } from 'lucide-react'
import { getPets, getPopularBreeds } from '@/lib/data'

export default function HomePage() {
  const { items: featuredPets } = getPets({ limit: 4 })
  const popularBreeds = getPopularBreeds()

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <SearchHero />

        {/* Popular Breeds Section */}
        <section className="py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="mb-10 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-foreground md:text-3xl">
                  Популярные породы
                </h2>
                <p className="mt-2 text-muted-foreground">
                  Найдите питомца любимой породы
                </p>
              </div>
              <Button variant="ghost" asChild className="hidden sm:flex">
                <Link href="/catalog">
                  Смотреть все
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>

            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
              {popularBreeds.map((breed) => (
                <BreedCard key={breed.id} breed={breed} />
              ))}
            </div>

            <div className="mt-6 text-center sm:hidden">
              <Button variant="outline" asChild>
                <Link href="/catalog">
                  Все породы
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </section>

        {/* Featured Listings Section */}
        <section className="bg-secondary/30 py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="mb-10 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-foreground md:text-3xl">
                  Новые объявления
                </h2>
                <p className="mt-2 text-muted-foreground">
                  Недавно добавленные питомцы ищут дом
                </p>
              </div>
              <Button variant="ghost" asChild className="hidden sm:flex">
                <Link href="/catalog">
                  Смотреть все
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>

            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {featuredPets.map((pet) => (
                <PetCard key={pet.id} pet={pet} />
              ))}
            </div>

            <div className="mt-8 text-center">
              <Button size="lg" asChild>
                <Link href="/catalog">
                  Смотреть все объявления
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <FeaturesSection />

        {/* CTA Section */}
        <section className="bg-primary py-16 md:py-24">
          <div className="container mx-auto px-4 text-center">
            <h2 className="mb-4 text-3xl font-bold text-primary-foreground md:text-4xl">
              Готовы найти нового лучшего друга?
            </h2>
            <p className="mx-auto mb-8 max-w-2xl text-primary-foreground/80">
              Присоединяйтесь к тысячам счастливых владельцев питомцев, которые нашли своих идеальных компаньонов через PetMarket.
            </p>
            <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Button size="lg" variant="secondary" asChild>
                <Link href="/catalog">Смотреть питомцев</Link>
              </Button>
              <Button size="lg" variant="outline" className="border-primary-foreground/20 text-primary-foreground hover:bg-primary-foreground/10" asChild>
                <Link href="/breeders">Найти заводчика</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
