'use client'

import { useSearchParams } from 'next/navigation'
import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet'
import { PetCard } from '@/components/pet-card'
import { CatalogFilters } from '@/components/catalog-filters'
import { getPets } from '@/lib/data'
import type { PetFilters, Gender, PetClass, PetType } from '@/lib/types'
import { Filter, LayoutGrid, List, ChevronLeft, ChevronRight } from 'lucide-react'

const sortOptions = [
  { value: 'newest', label: 'Сначала новые' },
  { value: 'price_asc', label: 'Цена: по возрастанию' },
  { value: 'price_desc', label: 'Цена: по убыванию' },
  { value: 'popular', label: 'По популярности' },
]

export function CatalogContent() {
  const searchParams = useSearchParams()
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false)

  // Build filters from URL params
  const filters: PetFilters = {
    type: searchParams.get('type') as PetType | undefined,
    breed: searchParams.get('breed') || undefined,
    city: searchParams.get('city') || undefined,
    priceMin: searchParams.get('priceMin') ? parseInt(searchParams.get('priceMin')!) : undefined,
    priceMax: searchParams.get('priceMax') ? parseInt(searchParams.get('priceMax')!) : undefined,
    gender: searchParams.get('gender') as Gender | undefined,
    petClass: searchParams.get('petClass') as PetClass | undefined,
    hasPedigree: searchParams.get('hasPedigree') === 'true' ? true : undefined,
    hasVaccination: searchParams.get('hasVaccination') === 'true' ? true : undefined,
    sort: (searchParams.get('sort') as PetFilters['sort']) || 'newest',
    page: searchParams.get('page') ? parseInt(searchParams.get('page')!) : 1,
    limit: 9,
    search: searchParams.get('search') || undefined,
  }

  const { items: pets, total, page, totalPages } = getPets(filters)

  const handleSortChange = (value: string) => {
    const params = new URLSearchParams(searchParams.toString())
    params.set('sort', value)
    params.delete('page')
    window.history.pushState(null, '', `/catalog?${params.toString()}`)
    window.location.reload()
  }

  const handlePageChange = (newPage: number) => {
    const params = new URLSearchParams(searchParams.toString())
    params.set('page', newPage.toString())
    window.history.pushState(null, '', `/catalog?${params.toString()}`)
    window.location.reload()
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex gap-8">
        {/* Desktop Sidebar */}
        <aside className="hidden w-72 shrink-0 lg:block">
          <div className="sticky top-24">
            <CatalogFilters />
          </div>
        </aside>

        {/* Main Content */}
        <div className="flex-1">
          {/* Toolbar */}
          <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              {/* Mobile Filter Button */}
              <Sheet open={mobileFiltersOpen} onOpenChange={setMobileFiltersOpen}>
                <SheetTrigger asChild>
                  <Button variant="outline" size="sm" className="lg:hidden">
                    <Filter className="mr-2 h-4 w-4" />
                    Фильтры
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-[320px] overflow-y-auto p-0">
                  <div className="p-4">
                    <CatalogFilters onClose={() => setMobileFiltersOpen(false)} />
                  </div>
                </SheetContent>
              </Sheet>

              <p className="text-sm text-muted-foreground">
                Найдено <span className="font-medium text-foreground">{total}</span> питомцев
              </p>
            </div>

            <div className="flex items-center gap-3">
              {/* Sort Select */}
              <Select value={filters.sort || 'newest'} onValueChange={handleSortChange}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {sortOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* View Toggle */}
              <div className="hidden items-center rounded-lg border border-border p-1 sm:flex">
                <Button
                  variant={viewMode === 'grid' ? 'secondary' : 'ghost'}
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => setViewMode('grid')}
                >
                  <LayoutGrid className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'secondary' : 'ghost'}
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => setViewMode('list')}
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Pet Grid/List */}
          {pets.length > 0 ? (
            <>
              <div
                className={
                  viewMode === 'grid'
                    ? 'grid gap-6 sm:grid-cols-2 xl:grid-cols-3'
                    : 'flex flex-col gap-4'
                }
              >
                {pets.map((pet) => (
                  <PetCard key={pet.id} pet={pet} variant={viewMode === 'list' ? 'compact' : 'default'} />
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="mt-8 flex items-center justify-center gap-2">
                  <Button
                    variant="outline"
                    size="icon"
                    disabled={page === 1}
                    onClick={() => handlePageChange(page - 1)}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>

                  {Array.from({ length: totalPages }, (_, i) => i + 1).map((pageNum) => (
                    <Button
                      key={pageNum}
                      variant={pageNum === page ? 'default' : 'outline'}
                      size="icon"
                      onClick={() => handlePageChange(pageNum)}
                    >
                      {pageNum}
                    </Button>
                  ))}

                  <Button
                    variant="outline"
                    size="icon"
                    disabled={page === totalPages}
                    onClick={() => handlePageChange(page + 1)}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </>
          ) : (
            <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border py-16 text-center">
              <div className="mb-4 text-6xl">&#128269;</div>
              <h3 className="mb-2 text-xl font-semibold">Питомцы не найдены</h3>
              <p className="mb-4 text-muted-foreground">
                Попробуйте изменить фильтры для получения большего количества результатов
              </p>
              <Button
                variant="outline"
                onClick={() => {
                  window.location.href = '/catalog'
                }}
              >
                Сбросить фильтры
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
