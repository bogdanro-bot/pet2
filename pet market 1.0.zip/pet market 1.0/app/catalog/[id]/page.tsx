import type { Metadata } from 'next'
import Link from 'next/link'
import Image from 'next/image'
import { notFound } from 'next/navigation'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { 
  MapPin, Phone, MessageCircle, Heart, Share2, 
  Star, ShieldCheck, Syringe, FileText, Eye, Calendar,
  CheckCircle2, XCircle, ChevronLeft, Dog, Cat
} from 'lucide-react'
import { getPetById, getReviewsByUserId } from '@/lib/data'

type PageParams = Promise<{ id: string }>

export async function generateMetadata({ params }: { params: PageParams }): Promise<Metadata> {
  const { id } = await params
  const pet = getPetById(id)
  
  if (!pet) {
    return { title: 'Питомец не найден' }
  }

  return {
    title: pet.title,
    description: pet.description,
    openGraph: {
      title: pet.title,
      description: pet.description,
      type: 'website',
    },
  }
}

export default async function PetDetailPage({ params }: { params: PageParams }) {
  const { id } = await params
  const pet = getPetById(id)

  if (!pet) {
    notFound()
  }

  const sellerReviews = pet.user ? getReviewsByUserId(pet.user.id) : []
  const avgRating = sellerReviews.length > 0 
    ? sellerReviews.reduce((sum, r) => sum + r.rating, 0) / sellerReviews.length 
    : 0

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('ru-RU', {
      style: 'currency',
      currency: 'RUB',
      minimumFractionDigits: 0,
    }).format(price * 100)
  }

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('ru-RU', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    }).format(new Date(date))
  }

  const healthChecklist = [
    { label: 'Документы о родословной', checked: pet.hasPedigree, icon: FileText },
    { label: 'Записи о вакцинации', checked: pet.hasVaccination, icon: Syringe },
    { label: 'Тесты здоровья', checked: pet.hasHealthTests, icon: ShieldCheck },
  ]

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      
      <main className="flex-1 bg-secondary/20 py-8">
        <div className="container mx-auto px-4">
          {/* Breadcrumb */}
          <div className="mb-6">
            <Link 
              href="/catalog" 
              className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground"
            >
              <ChevronLeft className="mr-1 h-4 w-4" />
              Назад в каталог
            </Link>
          </div>

          <div className="grid gap-8 lg:grid-cols-3">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Image Gallery */}
              <Card className="overflow-hidden">
                <div className="relative aspect-[4/3] bg-secondary">
                  <Image
                    src={pet.media?.[0]?.url || '/placeholder.svg'}
                    alt={pet.title}
                    fill
                    className="object-cover"
                    priority
                  />
                  {/* Badges */}
                  <div className="absolute left-4 top-4 flex flex-col gap-2">
                    {pet.isVip && (
                      <Badge className="bg-warning text-warning-foreground">
                        <Star className="mr-1 h-3 w-3" /> VIP-объявление
                      </Badge>
                    )}
                    {pet.petClass === 'SHOW' && (
                      <Badge className="bg-primary text-primary-foreground">
                        Шоу-класс
                      </Badge>
                    )}
                    {pet.petClass === 'BREED' && (
                      <Badge variant="secondary">
                        Брид-класс
                      </Badge>
                    )}
                  </div>
                  {/* Views */}
                  <div className="absolute bottom-4 right-4 flex items-center gap-1 rounded-full bg-background/90 px-3 py-1.5 text-sm backdrop-blur-sm">
                    <Eye className="h-4 w-4" />
                    {pet.views} просмотров
                  </div>
                </div>
              </Card>

              {/* Pet Info */}
              <Card>
                <CardContent className="p-6">
                  <div className="mb-4 flex flex-wrap items-start justify-between gap-4">
                    <div>
                      <h1 className="mb-2 text-2xl font-bold text-foreground md:text-3xl">
                        {pet.title}
                      </h1>
                      <div className="flex flex-wrap items-center gap-3 text-muted-foreground">
                        <span className="flex items-center gap-1">
                          {pet.type === 'DOG' ? <Dog className="h-4 w-4" /> : <Cat className="h-4 w-4" />}
                          {pet.breed}
                        </span>
                        <span>&bull;</span>
                        <span>{pet.age} {pet.age === 1 ? 'месяц' : pet.age < 5 ? 'месяца' : 'месяцев'}</span>
                        <span>&bull;</span>
                        <span>{pet.gender === 'MALE' ? 'Мальчик' : 'Девочка'}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-3xl font-bold text-primary">
                        {formatPrice(pet.price)}
                      </div>
                    </div>
                  </div>

                  <Separator className="my-4" />

                  <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      {pet.city}
                    </span>
                    <span className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      Опубликовано {formatDate(pet.createdAt)}
                    </span>
                  </div>
                </CardContent>
              </Card>

              {/* Description */}
              <Card>
                <CardHeader>
                  <CardTitle>Описание</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="whitespace-pre-wrap text-muted-foreground leading-relaxed">
                    {pet.description}
                  </p>
                </CardContent>
              </Card>

              {/* Health & Documents */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ShieldCheck className="h-5 w-5 text-accent" />
                    Здоровье и документы
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {healthChecklist.map((item) => (
                      <div
                        key={item.label}
                        className="flex items-center gap-3 rounded-lg border border-border p-3"
                      >
                        {item.checked ? (
                          <CheckCircle2 className="h-5 w-5 text-accent" />
                        ) : (
                          <XCircle className="h-5 w-5 text-muted-foreground/50" />
                        )}
                        <item.icon className="h-4 w-4 text-muted-foreground" />
                        <span className={item.checked ? 'text-foreground' : 'text-muted-foreground'}>
                          {item.label}
                        </span>
                        {item.checked && (
                          <Badge variant="outline" className="ml-auto text-accent">
                            Есть
                          </Badge>
                        )}
                      </div>
                    ))}
                  </div>
                  {pet.healthDetails && (
                    <div className="mt-4 rounded-lg bg-accent/10 p-4">
                      <p className="text-sm text-muted-foreground">{pet.healthDetails}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Sticky Contact Card */}
              <div className="lg:sticky lg:top-24">
                {/* Seller Info */}
                {pet.user && (
                  <Card className="mb-6">
                    <CardHeader>
                      <CardTitle className="text-lg">Информация о продавце</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center gap-4">
                        <Avatar className="h-14 w-14">
                          <AvatarFallback className="bg-primary text-primary-foreground text-lg">
                            {pet.user.name.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold text-foreground">{pet.user.name}</h3>
                            {pet.user.isVerified && (
                              <ShieldCheck className="h-4 w-4 text-accent" />
                            )}
                          </div>
                          <div className="flex items-center gap-1 text-sm text-warning">
                            <Star className="h-4 w-4 fill-current" />
                            <span>{avgRating.toFixed(1)}</span>
                            <span className="text-muted-foreground">
                              ({sellerReviews.length} отзывов)
                            </span>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {pet.user.role === 'BREEDER' ? 'Проверенный заводчик' : 'Частный продавец'}
                          </p>
                        </div>
                      </div>

                      {pet.user.role === 'BREEDER' && (
                        <div className="mt-4 rounded-lg bg-accent/10 p-3">
                          <div className="flex items-center gap-2 text-sm">
                            <ShieldCheck className="h-4 w-4 text-accent" />
                            <span className="font-medium text-accent">Надежный заводчик</span>
                          </div>
                          <p className="mt-1 text-xs text-muted-foreground">
                            Этот продавец является проверенным заводчиком с подтвержденными документами.
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}

                {/* Contact Actions */}
                <Card className="border-primary/20 bg-card">
                  <CardContent className="p-6 space-y-4">
                    <Button className="w-full" size="lg">
                      <Phone className="mr-2 h-4 w-4" />
                      Показать номер телефона
                    </Button>
                    <Button variant="outline" className="w-full" size="lg">
                      <MessageCircle className="mr-2 h-4 w-4" />
                      Написать сообщение
                    </Button>
                    <Separator />
                    <div className="flex gap-2">
                      <Button variant="outline" className="flex-1">
                        <Heart className="mr-2 h-4 w-4" />
                        Сохранить
                      </Button>
                      <Button variant="outline" className="flex-1">
                        <Share2 className="mr-2 h-4 w-4" />
                        Поделиться
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Safety Tips */}
                <Card className="mt-6 border-warning/20 bg-warning/5">
                  <CardContent className="p-4">
                    <h4 className="mb-2 font-semibold text-foreground">Советы по безопасности</h4>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li>• Встречайтесь с продавцом в безопасном публичном месте</li>
                      <li>• Запросите справки о здоровье и документы</li>
                      <li>• Никогда не отправляйте деньги до осмотра питомца</li>
                      <li>• Доверяйте своей интуиции</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
