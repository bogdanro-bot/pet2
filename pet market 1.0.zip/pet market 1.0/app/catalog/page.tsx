import { Suspense } from 'react'
import type { Metadata } from 'next'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { CatalogContent } from './catalog-content'

export const metadata: Metadata = {
  title: 'Каталог питомцев',
  description: 'Просматривайте наш обширный каталог собак, кошек и других питомцев от проверенных заводчиков.',
}

export default function CatalogPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 bg-secondary/20">
        <Suspense fallback={<CatalogSkeleton />}>
          <CatalogContent />
        </Suspense>
      </main>
      <Footer />
    </div>
  )
}

function CatalogSkeleton() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex gap-8">
        <div className="hidden w-72 lg:block">
          <div className="h-[600px] animate-pulse rounded-lg bg-muted" />
        </div>
        <div className="flex-1">
          <div className="mb-6 flex items-center justify-between">
            <div className="h-6 w-32 animate-pulse rounded bg-muted" />
            <div className="h-10 w-40 animate-pulse rounded bg-muted" />
          </div>
          <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="h-80 animate-pulse rounded-lg bg-muted" />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
