import type { Metadata, Viewport } from 'next'
import { Geist, Geist_Mono } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const geistSans = Geist({ 
  subsets: ['latin'],
  variable: '--font-geist-sans',
})

const geistMono = Geist_Mono({ 
  subsets: ['latin'],
  variable: '--font-geist-mono',
})

export const metadata: Metadata = {
  title: {
    default: 'PetMarket - Find Your Perfect Pet Companion',
    template: '%s | PetMarket',
  },
  description: 'The trusted marketplace for finding your perfect pet companion from verified breeders. Browse dogs, cats, and more from certified sellers.',
  keywords: ['pets', 'dogs', 'cats', 'puppies', 'kittens', 'breeders', 'pet marketplace', 'buy pets'],
  authors: [{ name: 'PetMarket' }],
  creator: 'PetMarket',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://petmarket.com',
    siteName: 'PetMarket',
    title: 'PetMarket - Find Your Perfect Pet Companion',
    description: 'The trusted marketplace for finding your perfect pet companion from verified breeders.',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'PetMarket - Find Your Perfect Pet Companion',
    description: 'The trusted marketplace for finding your perfect pet companion from verified breeders.',
  },
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#1e3a5f' },
    { media: '(prefers-color-scheme: dark)', color: '#0f172a' },
  ],
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${geistSans.variable} ${geistMono.variable}`}>
      <body className="font-sans antialiased">
        {children}
        <Analytics />
      </body>
    </html>
  )
}
